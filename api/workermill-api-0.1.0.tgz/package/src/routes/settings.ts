import { Router, Request, Response } from "express";
import {
  SecretsManagerClient,
  GetSecretValueCommand,
  PutSecretValueCommand,
  CreateSecretCommand,
  DeleteSecretCommand,
  ListSecretsCommand,
  ResourceNotFoundException,
} from "@aws-sdk/client-secrets-manager";
import { AppDataSource } from "../db/connection.js";
import { Organization, WebhookEndpoint, AuditLog, type IntegrationType, type AuditAction } from "../models/index.js";
import {
  ensureWebhookEndpoint,
  generateWebhookSecret,
  getWebhookEndpointsWithUrls,
} from "../services/webhook.js";
import { authenticateUser, authenticateRequest, requireAdmin } from "../middleware/auth.js";
import { logger } from "../utils/logger.js";
import {
  config,
  hasProviderCredentials,
  clearProviderCredentialsCache,
} from "../config/index.js";
import {
  listProviders,
  getProvider,
  hasProvider,
} from "../providers/index.js";
import { isValidProviderId, type ProviderId } from "../providers/types.js";
import { body, param, validateRequest } from "../middleware/validation.js";
import {
  getOrCreateExternalId,
  getAwsRoleConfig,
  saveAwsRoleConfig,
  isValidAwsRoleArn,
  extractAccountIdFromArn,
  type AwsRoleConfig,
} from "../services/external-id.js";
import { invalidateOrgCredentialsCache } from "../services/orchestrator.js";
import { invalidateOrgCredentialsCacheV2 } from "../services/orchestrator-v2.js";

const router = Router();

// Secrets Manager client
const secretsClient = new SecretsManagerClient({ region: config.aws.region });

// All routes require authentication (supports both JWT and API key)
router.use(authenticateRequest);

/**
 * GET /api/settings
 * Get all organization settings
 */
router.get("/", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;

    res.json({
      // Organization Identity
      slug: org.slug,
      name: org.name,

      // Data Management
      logRetentionDays: org.logRetentionDays,
      taskRetentionDays: org.taskRetentionDays,

      // Worker Settings
      maxConcurrentWorkers: org.maxConcurrentWorkers,
      defaultMaxRetries: org.defaultMaxRetries,
      taskCooldownSeconds: org.taskCooldownSeconds,
      defaultWorkerModel: org.defaultWorkerModel,
      defaultWorkerPersona: org.defaultWorkerPersona,

      // Warm Container Pool Settings
      warmPoolSize: org.warmPoolSize,
      warmPoolHoursStart: org.warmPoolHoursStart,
      warmPoolHoursEnd: org.warmPoolHoursEnd,
      warmPoolTimezone: org.warmPoolTimezone,

      // AI Provider Settings
      primaryProvider: org.primaryProvider || "anthropic",
      providerRouting: org.providerRouting || {},
      ollamaBaseUrl: org.ollamaBaseUrl || null,
      ollamaContextWindow: org.ollamaContextWindow || 65536,
      vllmBaseUrl: org.vllmBaseUrl || null,

      // Ralph Execution Settings
      useRalphExecution: org.useRalphExecution || false,
      ralphMaxStories: org.ralphMaxStories || 10,

      // Cost Settings
      costAlertThresholdUsd: org.costAlertThresholdUsd,

      // Budget Limits (AI FinOps)
      dailyBudgetLimitUsd: org.dailyBudgetLimitUsd,
      weeklyBudgetLimitUsd: org.weeklyBudgetLimitUsd,
      monthlyBudgetLimitUsd: org.monthlyBudgetLimitUsd,
      perTaskCostCeilingUsd: org.perTaskCostCeilingUsd,

      // Display Settings
      completedTaskDisplayMinutes: org.completedTaskDisplayMinutes,
      intermediateTaskDisplayMinutes: org.intermediateTaskDisplayMinutes,
      dryRunVisibilityMinutes: org.dryRunVisibilityMinutes,

      // Virtual Manager Settings
      managerProvider: org.managerProvider || "openai",
      managerModelId: org.managerModelId || "gpt-5.1-codex",
      maxReviewRevisions: org.maxReviewRevisions ?? 3,

      // Planning Agent Settings (Project Manager)
      planningAgentProvider: org.planningAgentProvider || "anthropic",
      planningAgentModel: org.planningAgentModel || "claude-sonnet-4-5-20250929",
      storyCalibrationMultiplier: org.storyCalibrationMultiplier ?? 0.4,

      // Email Settings
      emailFromAddress: org.emailFromAddress,
      emailNotificationsEnabled: org.emailNotificationsEnabled,
      emailLogRetentionDays: org.emailLogRetentionDays,
      defaultEmailPreferences: org.defaultEmailPreferences,

      // SCM Provider Settings
      scmProvider: org.scmProvider || "github",
      scmBaseUrl: org.scmBaseUrl || null,

      // Issue Tracker Provider Settings
      issueTrackerProvider: org.issueTrackerProvider || "jira",

      // Auto-Workflow Settings
      autoReviewEnabled: org.autoReviewEnabled ?? false,
      autoDeployEnabled: org.autoDeployEnabled ?? false,
      autoImproveEnabled: org.autoImproveEnabled ?? false,
      autoSkillExtraction: org.autoSkillExtraction ?? true,

      // Quality Gate Settings
      qualityGateEnabled: org.qualityGateEnabled ?? false,
      minQualityScore: org.minQualityScore,
      minTestCoveragePercent: org.minTestCoveragePercent,
      maxSecurityHighVulns: org.maxSecurityHighVulns,
      blockOnTypeErrors: org.blockOnTypeErrors ?? false,
      blockOnTestFailures: org.blockOnTestFailures ?? false,

      // External Quality Tool Integrations
      sonarqubeUrl: org.sonarqubeUrl || null,
      sonarqubeToken: org.sonarqubeToken ? "***" : null, // Mask token in response
      coderabbitEnabled: org.coderabbitEnabled ?? false,
      coderabbitApiKey: org.coderabbitApiKey ? "***" : null, // Mask API key in response
      deepsourceEnabled: org.deepsourceEnabled ?? false,
      deepsourceToken: org.deepsourceToken ? "***" : null, // Mask token in response
      qualityWebhookUrl: org.qualityWebhookUrl || null,
      qualityWebhookSecret: org.qualityWebhookSecret ? "***" : null, // Mask secret in response

      // Auto-Fix Settings
      autoFixEnabled: org.autoFixEnabled ?? false,
      autoFixMaxIterations: org.autoFixMaxIterations ?? 3,
      autoFixStats: org.autoFixStats || {},

      // System Settings (read-only for reference)
      systemEnabled: org.systemEnabled,
      orchestratorRunning: org.orchestratorRunning,
      managerEnabled: org.managerEnabled,

      // Resilience Settings
      blockerMaxAutoRetries: org.blockerMaxAutoRetries ?? 3,
      blockerAutoRetryEnabled: org.blockerAutoRetryEnabled ?? true,
      pushAfterCommit: org.pushAfterCommit ?? true,
      gracefulShutdownEnabled: org.gracefulShutdownEnabled ?? true,
      selfReviewEnabled: org.selfReviewEnabled ?? true,
    });
  } catch (error) {
    logger.error("Error getting settings", { error });
    res.status(500).json({ error: "Failed to get settings" });
  }
});

/**
 * PUT /api/settings
 * Update organization settings
 */
router.put("/", requireAdmin, async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const orgRepo = AppDataSource.getRepository(Organization);

    // Debug: log incoming request body
    logger.info("Settings update request", { body: req.body });

    const {
      // Data Management
      logRetentionDays,
      taskRetentionDays,

      // Worker Settings
      maxConcurrentWorkers,
      defaultMaxRetries,
      taskCooldownSeconds,
      defaultWorkerModel,
      defaultWorkerPersona,

      // Warm Container Pool Settings
      warmPoolSize,
      warmPoolHoursStart,
      warmPoolHoursEnd,
      warmPoolTimezone,

      // AI Provider Settings
      primaryProvider,
      providerRouting,
      ollamaBaseUrl,
      ollamaContextWindow,
      vllmBaseUrl,

      // Ralph Execution Settings
      useRalphExecution,
      ralphMaxStories,

      // Virtual Manager Settings
      managerProvider,
      managerModelId,
      maxReviewRevisions,

      // Planning Agent Settings (Project Manager)
      planningAgentProvider,
      planningAgentModel,
      storyCalibrationMultiplier,

      // Cost Settings
      costAlertThresholdUsd,

      // Budget Limits (AI FinOps)
      dailyBudgetLimitUsd,
      weeklyBudgetLimitUsd,
      monthlyBudgetLimitUsd,
      perTaskCostCeilingUsd,

      // Display Settings
      completedTaskDisplayMinutes,
      intermediateTaskDisplayMinutes,
      dryRunVisibilityMinutes,

      // Email Settings
      emailFromAddress,
      emailNotificationsEnabled,
      emailLogRetentionDays,
      defaultEmailPreferences,

      // SCM Provider Settings
      scmProvider,
      scmBaseUrl,

      // Issue Tracker Provider Settings
      issueTrackerProvider,

      // Auto-Workflow Settings
      autoReviewEnabled,
      autoDeployEnabled,
      autoImproveEnabled,
      autoSkillExtraction,

      // Quality Gate Settings
      qualityGateEnabled,
      minQualityScore,
      minTestCoveragePercent,
      maxSecurityHighVulns,
      blockOnTypeErrors,
      blockOnTestFailures,

      // External Quality Tool Integrations
      sonarqubeUrl,
      sonarqubeToken,
      coderabbitEnabled,
      coderabbitApiKey,
      deepsourceEnabled,
      deepsourceToken,
      qualityWebhookUrl,
      qualityWebhookSecret,
      autoFixEnabled,
      autoFixMaxIterations,

      // Resilience Settings
      blockerMaxAutoRetries,
      blockerAutoRetryEnabled,
      pushAfterCommit,
      gracefulShutdownEnabled,
      selfReviewEnabled,
    } = req.body;

    // Validate and update Data Management settings
    if (logRetentionDays !== undefined) {
      const days = parseInt(logRetentionDays, 10);
      if (isNaN(days) || days < 1 || days > 365) {
        res.status(400).json({ error: "logRetentionDays must be between 1 and 365" });
        return;
      }
      org.logRetentionDays = days;
    }

    if (taskRetentionDays !== undefined) {
      const days = parseInt(taskRetentionDays, 10);
      if (isNaN(days) || days < 1 || days > 730) {
        res.status(400).json({ error: "taskRetentionDays must be between 1 and 730" });
        return;
      }
      org.taskRetentionDays = days;
    }

    // Validate and update Worker Settings
    if (maxConcurrentWorkers !== undefined) {
      const max = parseInt(maxConcurrentWorkers, 10);
      if (isNaN(max) || max < 1 || max > 10) {
        res.status(400).json({ error: "maxConcurrentWorkers must be between 1 and 10" });
        return;
      }
      org.maxConcurrentWorkers = max;
    }

    // Validate and update Warm Container Pool Settings
    if (warmPoolSize !== undefined) {
      const size = parseInt(warmPoolSize, 10);
      if (isNaN(size) || size < 0 || size > 5) {
        res.status(400).json({ error: "warmPoolSize must be between 0 and 5" });
        return;
      }
      org.warmPoolSize = size;
    }

    if (warmPoolHoursStart !== undefined) {
      const hour = parseInt(warmPoolHoursStart, 10);
      if (isNaN(hour) || hour < 0 || hour > 23) {
        res.status(400).json({ error: "warmPoolHoursStart must be between 0 and 23" });
        return;
      }
      org.warmPoolHoursStart = hour;
    }

    if (warmPoolHoursEnd !== undefined) {
      const hour = parseInt(warmPoolHoursEnd, 10);
      if (isNaN(hour) || hour < 0 || hour > 23) {
        res.status(400).json({ error: "warmPoolHoursEnd must be between 0 and 23" });
        return;
      }
      org.warmPoolHoursEnd = hour;
    }

    if (warmPoolTimezone !== undefined) {
      // Validate timezone by trying to use it
      try {
        new Intl.DateTimeFormat("en-US", { timeZone: warmPoolTimezone });
        org.warmPoolTimezone = warmPoolTimezone;
      } catch {
        res.status(400).json({ error: "Invalid warmPoolTimezone. Use IANA timezone format (e.g., America/New_York)" });
        return;
      }
    }

    if (defaultMaxRetries !== undefined) {
      const retries = parseInt(defaultMaxRetries, 10);
      if (isNaN(retries) || retries < 0 || retries > 10) {
        res.status(400).json({ error: "defaultMaxRetries must be between 0 and 10" });
        return;
      }
      org.defaultMaxRetries = retries;
    }

    if (taskCooldownSeconds !== undefined) {
      const cooldown = parseInt(taskCooldownSeconds, 10);
      if (isNaN(cooldown) || cooldown < 0 || cooldown > 86400) {
        res.status(400).json({ error: "taskCooldownSeconds must be between 0 and 86400 (24 hours)" });
        return;
      }
      org.taskCooldownSeconds = cooldown;
    }

    if (defaultWorkerModel !== undefined) {
      // Use dynamic model discovery for validation
      const { models: availableModels } = await getAvailableModels(org);

      if (!isValidModelId(defaultWorkerModel, availableModels)) {
        res.status(400).json({
          error: "Invalid defaultWorkerModel",
          hint: "Use GET /api/settings/models to see available models",
        });
        return;
      }
      org.defaultWorkerModel = defaultWorkerModel;

      // Auto-correct primaryProvider if it doesn't match the model
      const inferredProvider = inferProviderFromModelId(defaultWorkerModel);
      if (inferredProvider && inferredProvider !== org.primaryProvider && inferredProvider !== "ollama") {
        logger.info("Auto-correcting primaryProvider to match defaultWorkerModel", {
          orgId: org.id,
          model: defaultWorkerModel,
          oldProvider: org.primaryProvider,
          newProvider: inferredProvider,
        });
        org.primaryProvider = inferredProvider;
      }
    }

    if (defaultWorkerPersona !== undefined) {
      const validPersonas = [
        "auto",
        "frontend_developer",
        "backend_developer",
        "devops_engineer",
        "security_engineer",
        "qa_engineer",
        "tech_writer",
        "project_manager",
        "api_developer",
        "database_administrator",
        "ml_engineer",
        "data_engineer",
        "mobile_developer_ios",
        "mobile_developer_android",
        "tech_lead",
      ];
      if (!validPersonas.includes(defaultWorkerPersona)) {
        res.status(400).json({ error: "Invalid defaultWorkerPersona" });
        return;
      }
      org.defaultWorkerPersona = defaultWorkerPersona;
    }

    // Validate and update AI Provider Settings
    if (primaryProvider !== undefined) {
      const validProviders = ["anthropic", "openai", "google", "ollama", "openrouter", "groq", "deepseek", "mistral", "xai", "bedrock", "azure"];
      if (!validProviders.includes(primaryProvider)) {
        res.status(400).json({ error: "Invalid primaryProvider. Must be one of: anthropic, openai, google, ollama, openrouter, groq, deepseek, mistral, xai, bedrock, azure" });
        return;
      }
      org.primaryProvider = primaryProvider;
    }

    // Validate and update Provider Routing
    // Format: { "persona_name": { "provider": "ollama", "model": "qwen2.5-coder:32b" } }
    if (providerRouting !== undefined) {
      if (typeof providerRouting !== "object" || providerRouting === null) {
        res.status(400).json({ error: "providerRouting must be an object" });
        return;
      }
      const validProviders = ["anthropic", "openai", "google", "ollama", "openrouter", "groq", "deepseek", "mistral", "xai", "bedrock", "azure"];
      const validPersonas = [
        "frontend_developer",
        "backend_developer",
        "devops_engineer",
        "security_engineer",
        "qa_engineer",
        "tech_writer",
        "project_manager",
      ];
      for (const [persona, config] of Object.entries(providerRouting)) {
        if (!validPersonas.includes(persona)) {
          res.status(400).json({ error: `Invalid persona in providerRouting: ${persona}` });
          return;
        }
        const routeConfig = config as { provider?: string; model?: string };
        if (!routeConfig.provider || !validProviders.includes(routeConfig.provider)) {
          res.status(400).json({ error: `Invalid provider for persona ${persona}` });
          return;
        }
      }
      org.providerRouting = providerRouting;
    }

    // Validate and update Ollama Base URL
    if (ollamaBaseUrl !== undefined) {
      if (ollamaBaseUrl === null || ollamaBaseUrl === "") {
        org.ollamaBaseUrl = null;
      } else {
        // Basic URL validation
        try {
          new URL(ollamaBaseUrl);
          org.ollamaBaseUrl = ollamaBaseUrl;
        } catch {
          res.status(400).json({ error: "Invalid ollamaBaseUrl. Must be a valid URL." });
          return;
        }
      }
    }

    // Validate and update Ollama Context Window
    if (ollamaContextWindow !== undefined) {
      const ctxWindow = parseInt(ollamaContextWindow, 10);
      if (isNaN(ctxWindow) || ctxWindow < 2048 || ctxWindow > 262144) {
        res.status(400).json({ error: "ollamaContextWindow must be between 2048 and 262144 tokens" });
        return;
      }
      org.ollamaContextWindow = ctxWindow;
    }

    // Validate and update vLLM Base URL (GPU inference endpoint)
    if (vllmBaseUrl !== undefined) {
      if (vllmBaseUrl === null || vllmBaseUrl === "") {
        org.vllmBaseUrl = null;
      } else {
        // Basic URL validation
        try {
          new URL(vllmBaseUrl);
          org.vllmBaseUrl = vllmBaseUrl;
        } catch {
          res.status(400).json({ error: "Invalid vllmBaseUrl. Must be a valid URL." });
          return;
        }
      }
    }

    // Validate and update Ralph Execution Settings
    if (useRalphExecution !== undefined) {
      org.useRalphExecution = Boolean(useRalphExecution);
    }

    if (ralphMaxStories !== undefined) {
      const maxStories = parseInt(ralphMaxStories, 10);
      if (isNaN(maxStories) || maxStories < 1 || maxStories > 50) {
        res.status(400).json({ error: "ralphMaxStories must be between 1 and 50" });
        return;
      }
      org.ralphMaxStories = maxStories;
    }

    // Validate and update Virtual Manager Settings
    if (managerProvider !== undefined) {
      const validProviders = ["anthropic", "openai", "google", "ollama", "openrouter", "groq", "deepseek", "mistral", "xai", "bedrock", "azure"];
      if (!validProviders.includes(managerProvider)) {
        res.status(400).json({ error: "Invalid managerProvider. Must be one of: anthropic, openai, google, ollama, openrouter, groq, deepseek, mistral, xai, bedrock, azure" });
        return;
      }
      org.managerProvider = managerProvider;
    }

    if (managerModelId !== undefined) {
      // Use dynamic model discovery for validation (same pool as worker models)
      const { models: availableModels } = await getAvailableModels(org);

      if (!isValidModelId(managerModelId, availableModels)) {
        res.status(400).json({
          error: "Invalid managerModelId",
          hint: "Use GET /api/settings/models to see available models",
        });
        return;
      }
      org.managerModelId = managerModelId;

      // Auto-correct provider if it doesn't match the model
      const inferredProvider = inferProviderFromModelId(managerModelId);
      if (inferredProvider && inferredProvider !== org.managerProvider) {
        logger.info("Auto-correcting managerProvider to match model", {
          orgId: org.id,
          model: managerModelId,
          oldProvider: org.managerProvider,
          newProvider: inferredProvider,
        });
        org.managerProvider = inferredProvider;
      }
    }

    if (maxReviewRevisions !== undefined) {
      const value = Number(maxReviewRevisions);
      if (isNaN(value) || value < 1 || value > 10) {
        res.status(400).json({ error: "maxReviewRevisions must be between 1 and 10" });
        return;
      }
      org.maxReviewRevisions = value;
    }

    // Validate and update Planning Agent Settings (Project Manager)
    if (planningAgentProvider !== undefined) {
      const validProviders = ["anthropic", "openai", "google", "ollama", "openrouter", "groq", "deepseek", "mistral", "xai", "bedrock", "azure"];
      if (!validProviders.includes(planningAgentProvider)) {
        res.status(400).json({ error: "Invalid planningAgentProvider. Must be one of: anthropic, openai, google, ollama, openrouter, groq, deepseek, mistral, xai, bedrock, azure" });
        return;
      }
      org.planningAgentProvider = planningAgentProvider;
    }

    if (planningAgentModel !== undefined) {
      const { models: availableModels } = await getAvailableModels(org);

      if (!isValidModelId(planningAgentModel, availableModels)) {
        res.status(400).json({
          error: "Invalid planningAgentModel",
          hint: "Use GET /api/settings/models to see available models",
        });
        return;
      }
      org.planningAgentModel = planningAgentModel;

      // Auto-correct provider if it doesn't match the model
      const inferredProvider = inferProviderFromModelId(planningAgentModel);
      if (inferredProvider && inferredProvider !== org.planningAgentProvider) {
        logger.info("Auto-correcting planningAgentProvider to match model", {
          orgId: org.id,
          model: planningAgentModel,
          oldProvider: org.planningAgentProvider,
          newProvider: inferredProvider,
        });
        org.planningAgentProvider = inferredProvider;
      }
    }

    if (storyCalibrationMultiplier !== undefined) {
      const multiplier = parseFloat(storyCalibrationMultiplier);
      if (isNaN(multiplier) || multiplier < 0.1 || multiplier > 2.0) {
        res.status(400).json({ error: "storyCalibrationMultiplier must be between 0.1 and 2.0" });
        return;
      }
      org.storyCalibrationMultiplier = multiplier;
    }

    // Validate and update Cost Settings
    if (costAlertThresholdUsd !== undefined) {
      if (costAlertThresholdUsd === null || costAlertThresholdUsd === "") {
        org.costAlertThresholdUsd = null;
      } else {
        const threshold = parseFloat(costAlertThresholdUsd);
        if (isNaN(threshold) || threshold < 0 || threshold > 100000) {
          res.status(400).json({ error: "costAlertThresholdUsd must be between 0 and 100000" });
          return;
        }
        org.costAlertThresholdUsd = threshold;
      }
    }

    // Validate and update Budget Limits (AI FinOps)
    if (dailyBudgetLimitUsd !== undefined) {
      if (dailyBudgetLimitUsd === null || dailyBudgetLimitUsd === "") {
        org.dailyBudgetLimitUsd = null;
      } else {
        const limit = parseFloat(dailyBudgetLimitUsd);
        if (isNaN(limit) || limit < 0 || limit > 100000) {
          res.status(400).json({ error: "dailyBudgetLimitUsd must be between 0 and 100000" });
          return;
        }
        org.dailyBudgetLimitUsd = limit;
      }
    }

    if (weeklyBudgetLimitUsd !== undefined) {
      if (weeklyBudgetLimitUsd === null || weeklyBudgetLimitUsd === "") {
        org.weeklyBudgetLimitUsd = null;
      } else {
        const limit = parseFloat(weeklyBudgetLimitUsd);
        if (isNaN(limit) || limit < 0 || limit > 100000) {
          res.status(400).json({ error: "weeklyBudgetLimitUsd must be between 0 and 100000" });
          return;
        }
        org.weeklyBudgetLimitUsd = limit;
      }
    }

    if (monthlyBudgetLimitUsd !== undefined) {
      if (monthlyBudgetLimitUsd === null || monthlyBudgetLimitUsd === "") {
        org.monthlyBudgetLimitUsd = null;
      } else {
        const limit = parseFloat(monthlyBudgetLimitUsd);
        if (isNaN(limit) || limit < 0 || limit > 100000) {
          res.status(400).json({ error: "monthlyBudgetLimitUsd must be between 0 and 100000" });
          return;
        }
        org.monthlyBudgetLimitUsd = limit;
      }
    }

    if (perTaskCostCeilingUsd !== undefined) {
      if (perTaskCostCeilingUsd === null || perTaskCostCeilingUsd === "") {
        org.perTaskCostCeilingUsd = null;
      } else {
        const ceiling = parseFloat(perTaskCostCeilingUsd);
        if (isNaN(ceiling) || ceiling < 0 || ceiling > 10000) {
          res.status(400).json({ error: "perTaskCostCeilingUsd must be between 0 and 10000" });
          return;
        }
        org.perTaskCostCeilingUsd = ceiling;
      }
    }

    // Validate and update Display Settings
    if (completedTaskDisplayMinutes !== undefined) {
      const minutes = parseInt(completedTaskDisplayMinutes, 10);
      if (isNaN(minutes) || minutes < 1 || minutes > 60) {
        res.status(400).json({ error: "completedTaskDisplayMinutes must be between 1 and 60" });
        return;
      }
      org.completedTaskDisplayMinutes = minutes;
    }

    if (intermediateTaskDisplayMinutes !== undefined) {
      const minutes = parseInt(intermediateTaskDisplayMinutes, 10);
      if (isNaN(minutes) || minutes < 1 || minutes > 1440) {
        res.status(400).json({ error: "intermediateTaskDisplayMinutes must be between 1 and 1440 (24 hours)" });
        return;
      }
      org.intermediateTaskDisplayMinutes = minutes;
    }

    if (dryRunVisibilityMinutes !== undefined) {
      const minutes = parseInt(dryRunVisibilityMinutes, 10);
      if (isNaN(minutes) || minutes < 1 || minutes > 60) {
        res.status(400).json({ error: "dryRunVisibilityMinutes must be between 1 and 60" });
        return;
      }
      org.dryRunVisibilityMinutes = minutes;
    }

    // Validate and update Email Settings
    if (emailFromAddress !== undefined) {
      if (emailFromAddress === null || emailFromAddress === "") {
        org.emailFromAddress = null;
      } else {
        // Basic email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(emailFromAddress)) {
          res.status(400).json({ error: "emailFromAddress must be a valid email address" });
          return;
        }
        org.emailFromAddress = emailFromAddress;
      }
    }

    if (emailNotificationsEnabled !== undefined) {
      org.emailNotificationsEnabled = Boolean(emailNotificationsEnabled);
    }

    if (emailLogRetentionDays !== undefined) {
      const days = parseInt(emailLogRetentionDays, 10);
      if (isNaN(days) || days < 1 || days > 365) {
        res.status(400).json({ error: "emailLogRetentionDays must be between 1 and 365" });
        return;
      }
      org.emailLogRetentionDays = days;
    }

    if (defaultEmailPreferences !== undefined) {
      if (typeof defaultEmailPreferences !== "object" || defaultEmailPreferences === null) {
        res.status(400).json({ error: "defaultEmailPreferences must be an object" });
        return;
      }
      const validKeys = ["taskCompleted", "taskFailed", "costAlerts", "prCreated", "frequency"];
      const invalidKeys = Object.keys(defaultEmailPreferences).filter((k) => !validKeys.includes(k));
      if (invalidKeys.length > 0) {
        res.status(400).json({ error: `Invalid keys in defaultEmailPreferences: ${invalidKeys.join(", ")}` });
        return;
      }
      org.defaultEmailPreferences = defaultEmailPreferences;
    }

    // Validate and update SCM Provider settings
    if (scmProvider !== undefined) {
      const validProviders = ["github", "gitlab", "bitbucket"];
      if (!validProviders.includes(scmProvider)) {
        res.status(400).json({ error: "scmProvider must be: github, gitlab, or bitbucket" });
        return;
      }
      org.scmProvider = scmProvider;
    }

    if (scmBaseUrl !== undefined) {
      if (scmBaseUrl === null || scmBaseUrl === "") {
        org.scmBaseUrl = null;
      } else {
        // Basic URL validation
        try {
          new URL(scmBaseUrl);
          org.scmBaseUrl = scmBaseUrl;
        } catch {
          res.status(400).json({ error: "scmBaseUrl must be a valid URL" });
          return;
        }
      }
    }

    // Validate and update Issue Tracker Provider settings
    if (issueTrackerProvider !== undefined) {
      const validTrackers = ["jira", "linear", "github-issues"];
      if (!validTrackers.includes(issueTrackerProvider)) {
        res.status(400).json({ error: "issueTrackerProvider must be: jira, linear, or github-issues" });
        return;
      }
      org.issueTrackerProvider = issueTrackerProvider;
    }

    // Validate and update Auto-Workflow Settings
    if (autoReviewEnabled !== undefined) {
      org.autoReviewEnabled = Boolean(autoReviewEnabled);
    }

    if (autoDeployEnabled !== undefined) {
      org.autoDeployEnabled = Boolean(autoDeployEnabled);
    }

    if (autoImproveEnabled !== undefined) {
      org.autoImproveEnabled = Boolean(autoImproveEnabled);
    }

    if (autoSkillExtraction !== undefined) {
      org.autoSkillExtraction = Boolean(autoSkillExtraction);
    }

    // Validate and update Quality Gate Settings
    if (qualityGateEnabled !== undefined) {
      org.qualityGateEnabled = Boolean(qualityGateEnabled);
    }

    if (minQualityScore !== undefined) {
      if (minQualityScore === null) {
        org.minQualityScore = null;
      } else {
        const score = parseInt(minQualityScore, 10);
        if (isNaN(score) || score < 0 || score > 100) {
          res.status(400).json({ error: "minQualityScore must be between 0 and 100" });
          return;
        }
        org.minQualityScore = score;
      }
    }

    if (minTestCoveragePercent !== undefined) {
      if (minTestCoveragePercent === null) {
        org.minTestCoveragePercent = null;
      } else {
        const coverage = parseInt(minTestCoveragePercent, 10);
        if (isNaN(coverage) || coverage < 0 || coverage > 100) {
          res.status(400).json({ error: "minTestCoveragePercent must be between 0 and 100" });
          return;
        }
        org.minTestCoveragePercent = coverage;
      }
    }

    if (maxSecurityHighVulns !== undefined) {
      if (maxSecurityHighVulns === null) {
        org.maxSecurityHighVulns = null;
      } else {
        const vulns = parseInt(maxSecurityHighVulns, 10);
        if (isNaN(vulns) || vulns < 0) {
          res.status(400).json({ error: "maxSecurityHighVulns must be 0 or greater" });
          return;
        }
        org.maxSecurityHighVulns = vulns;
      }
    }

    if (blockOnTypeErrors !== undefined) {
      org.blockOnTypeErrors = Boolean(blockOnTypeErrors);
    }

    if (blockOnTestFailures !== undefined) {
      org.blockOnTestFailures = Boolean(blockOnTestFailures);
    }

    // Validate and update External Quality Tool Integrations
    if (sonarqubeUrl !== undefined) {
      if (sonarqubeUrl === null || sonarqubeUrl === "") {
        org.sonarqubeUrl = null;
      } else {
        // Basic URL validation
        try {
          new URL(sonarqubeUrl);
          org.sonarqubeUrl = sonarqubeUrl;
        } catch {
          res.status(400).json({ error: "sonarqubeUrl must be a valid URL" });
          return;
        }
      }
    }

    if (sonarqubeToken !== undefined) {
      // Allow clearing token with null/empty, or updating with new token
      // Don't update if token is the masked value "***"
      if (sonarqubeToken === null || sonarqubeToken === "") {
        org.sonarqubeToken = null;
      } else if (sonarqubeToken !== "***") {
        org.sonarqubeToken = sonarqubeToken;
      }
    }

    if (coderabbitEnabled !== undefined) {
      org.coderabbitEnabled = Boolean(coderabbitEnabled);
    }

    if (coderabbitApiKey !== undefined) {
      // Allow clearing key with null/empty, or updating with new key
      // Don't update if key is the masked value "***"
      if (coderabbitApiKey === null || coderabbitApiKey === "") {
        org.coderabbitApiKey = null;
      } else if (coderabbitApiKey !== "***") {
        org.coderabbitApiKey = coderabbitApiKey;
      }
    }

    if (deepsourceEnabled !== undefined) {
      org.deepsourceEnabled = Boolean(deepsourceEnabled);
    }

    if (deepsourceToken !== undefined) {
      // Allow clearing token with null/empty, or updating with new token
      // Don't update if token is the masked value "***"
      if (deepsourceToken === null || deepsourceToken === "") {
        org.deepsourceToken = null;
      } else if (deepsourceToken !== "***") {
        org.deepsourceToken = deepsourceToken;
      }
    }

    if (qualityWebhookUrl !== undefined) {
      if (qualityWebhookUrl === null || qualityWebhookUrl === "") {
        org.qualityWebhookUrl = null;
      } else {
        // Basic URL validation
        try {
          new URL(qualityWebhookUrl);
          org.qualityWebhookUrl = qualityWebhookUrl;
        } catch {
          res.status(400).json({ error: "qualityWebhookUrl must be a valid URL" });
          return;
        }
      }
    }

    if (qualityWebhookSecret !== undefined) {
      // Allow clearing secret with null/empty, or updating with new secret
      // Don't update if secret is the masked value "***"
      if (qualityWebhookSecret === null || qualityWebhookSecret === "") {
        org.qualityWebhookSecret = null;
      } else if (qualityWebhookSecret !== "***") {
        org.qualityWebhookSecret = qualityWebhookSecret;
      }
    }

    // Auto-Fix Settings
    if (autoFixEnabled !== undefined) {
      org.autoFixEnabled = autoFixEnabled === true;
    }

    if (autoFixMaxIterations !== undefined) {
      const maxIter = parseInt(autoFixMaxIterations, 10);
      if (isNaN(maxIter) || maxIter < 1 || maxIter > 10) {
        res.status(400).json({ error: "autoFixMaxIterations must be between 1 and 10" });
        return;
      }
      org.autoFixMaxIterations = maxIter;
    }

    // Resilience Settings
    if (blockerMaxAutoRetries !== undefined) {
      const maxRetries = parseInt(blockerMaxAutoRetries, 10);
      if (isNaN(maxRetries) || maxRetries < 0 || maxRetries > 10) {
        res.status(400).json({ error: "blockerMaxAutoRetries must be between 0 and 10" });
        return;
      }
      org.blockerMaxAutoRetries = maxRetries;
    }

    if (blockerAutoRetryEnabled !== undefined) {
      org.blockerAutoRetryEnabled = blockerAutoRetryEnabled === true;
    }

    if (pushAfterCommit !== undefined) {
      org.pushAfterCommit = pushAfterCommit === true;
    }

    if (gracefulShutdownEnabled !== undefined) {
      org.gracefulShutdownEnabled = gracefulShutdownEnabled === true;
    }

    if (selfReviewEnabled !== undefined) {
      org.selfReviewEnabled = selfReviewEnabled === true;
    }

    await orgRepo.save(org);

    // Invalidate cached credentials so workers immediately pick up new settings
    // (e.g., managerProvider, managerModelId, providerRouting, scmProvider changes)
    invalidateOrgCredentialsCache(org.id);
    invalidateOrgCredentialsCacheV2(org.id);

    logger.info("Organization settings updated", {
      orgId: org.id,
      updatedFields: Object.keys(req.body),
    });

    res.json({
      success: true,
      message: "Settings updated successfully",
      settings: {
        logRetentionDays: org.logRetentionDays,
        taskRetentionDays: org.taskRetentionDays,
        maxConcurrentWorkers: org.maxConcurrentWorkers,
        defaultMaxRetries: org.defaultMaxRetries,
        taskCooldownSeconds: org.taskCooldownSeconds,
        defaultWorkerModel: org.defaultWorkerModel,
        defaultWorkerPersona: org.defaultWorkerPersona,
        primaryProvider: org.primaryProvider,
        providerRouting: org.providerRouting,
        ollamaBaseUrl: org.ollamaBaseUrl,
        ollamaContextWindow: org.ollamaContextWindow,
        vllmBaseUrl: org.vllmBaseUrl,
        useRalphExecution: org.useRalphExecution,
        ralphMaxStories: org.ralphMaxStories,
        managerProvider: org.managerProvider,
        managerModelId: org.managerModelId,
        maxReviewRevisions: org.maxReviewRevisions,
        planningAgentProvider: org.planningAgentProvider,
        planningAgentModel: org.planningAgentModel,
        storyCalibrationMultiplier: org.storyCalibrationMultiplier,
        costAlertThresholdUsd: org.costAlertThresholdUsd,
        dailyBudgetLimitUsd: org.dailyBudgetLimitUsd,
        weeklyBudgetLimitUsd: org.weeklyBudgetLimitUsd,
        monthlyBudgetLimitUsd: org.monthlyBudgetLimitUsd,
        perTaskCostCeilingUsd: org.perTaskCostCeilingUsd,
        completedTaskDisplayMinutes: org.completedTaskDisplayMinutes,
        intermediateTaskDisplayMinutes: org.intermediateTaskDisplayMinutes,
        dryRunVisibilityMinutes: org.dryRunVisibilityMinutes,
        emailFromAddress: org.emailFromAddress,
        emailNotificationsEnabled: org.emailNotificationsEnabled,
        emailLogRetentionDays: org.emailLogRetentionDays,
        defaultEmailPreferences: org.defaultEmailPreferences,
        scmProvider: org.scmProvider,
        scmBaseUrl: org.scmBaseUrl,
        issueTrackerProvider: org.issueTrackerProvider,
        autoReviewEnabled: org.autoReviewEnabled,
        autoDeployEnabled: org.autoDeployEnabled,
        autoImproveEnabled: org.autoImproveEnabled,
        autoSkillExtraction: org.autoSkillExtraction,
        qualityGateEnabled: org.qualityGateEnabled,
        minQualityScore: org.minQualityScore,
        minTestCoveragePercent: org.minTestCoveragePercent,
        maxSecurityHighVulns: org.maxSecurityHighVulns,
        blockOnTypeErrors: org.blockOnTypeErrors,
        blockOnTestFailures: org.blockOnTestFailures,
        sonarqubeUrl: org.sonarqubeUrl || null,
        sonarqubeToken: org.sonarqubeToken ? "***" : null,
        coderabbitEnabled: org.coderabbitEnabled,
        coderabbitApiKey: org.coderabbitApiKey ? "***" : null,
        deepsourceEnabled: org.deepsourceEnabled,
        deepsourceToken: org.deepsourceToken ? "***" : null,
        qualityWebhookUrl: org.qualityWebhookUrl || null,
        qualityWebhookSecret: org.qualityWebhookSecret ? "***" : null,
        autoFixEnabled: org.autoFixEnabled ?? false,
        autoFixMaxIterations: org.autoFixMaxIterations ?? 3,
        autoFixStats: org.autoFixStats || {},
        // Resilience Settings
        blockerMaxAutoRetries: org.blockerMaxAutoRetries ?? 3,
        blockerAutoRetryEnabled: org.blockerAutoRetryEnabled ?? true,
        pushAfterCommit: org.pushAfterCommit ?? true,
        gracefulShutdownEnabled: org.gracefulShutdownEnabled ?? true,
        selfReviewEnabled: org.selfReviewEnabled ?? true,
      },
    });
  } catch (error) {
    logger.error("Error updating settings", { error });
    res.status(500).json({ error: "Failed to update settings" });
  }
});

/**
 * POST /api/settings/test-email
 * Send a test email to the current user
 */
router.post("/test-email", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const user = req.user!;

    // Import the email service
    const { sendTestEmail } = await import("../services/email.js");

    const success = await sendTestEmail(user, org);

    if (success) {
      logger.info("Test email sent successfully", {
        userId: user.id,
        email: user.email,
        orgId: org.id,
      });
      res.json({ success: true, message: `Test email sent to ${user.email}` });
    } else {
      res.status(500).json({ success: false, error: "Failed to send test email" });
    }
  } catch (error) {
    logger.error("Error sending test email", { error });
    res.status(500).json({ success: false, error: "Failed to send test email" });
  }
});

/**
 * POST /api/settings/test-welcome-email
 * Send a test welcome email to the current user (for testing the welcome email template)
 */
router.post("/test-welcome-email", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const user = req.user!;

    const { sendWelcomeEmail } = await import("../services/email.js");

    // Send welcome email (joinedViaInvite = false for testing)
    const success = await sendWelcomeEmail(user, org, false);

    if (success) {
      logger.info("Test welcome email sent successfully", {
        userId: user.id,
        orgId: org.id,
        email: user.email,
      });
      res.json({ success: true, message: `Welcome email sent to ${user.email}` });
    } else {
      res.status(500).json({ success: false, error: "Failed to send welcome email" });
    }
  } catch (error) {
    logger.error("Error sending test welcome email", { error });
    res.status(500).json({ success: false, error: "Failed to send welcome email" });
  }
});

/**
 * Get organization-specific secret from AWS Secrets Manager.
 * SECURITY: Only returns org-specific secrets - NO platform fallback for multi-tenancy isolation.
 * Each organization must configure their own credentials.
 */
async function getOrgSecret(
  orgId: string,
  secretName: string,
  secretPrefix: string
): Promise<string | null> {
  // Only return org-specific secrets - no platform fallback for multi-tenancy security
  try {
    const orgSecret = await secretsClient.send(
      new GetSecretValueCommand({
        SecretId: `${secretPrefix}/orgs/${orgId}/${secretName}`,
      })
    );
    if (orgSecret.SecretString) return orgSecret.SecretString;
  } catch {
    // Not found at org level - return null (no fallback to shared secrets)
  }

  return null;
}

/**
 * Helper to get platform-wide secret (for truly shared resources only)
 * Use sparingly - only for platform infrastructure, not tenant data
 */
async function getPlatformSecret(
  secretName: string,
  secretPrefix: string
): Promise<string | null> {
  try {
    const platformSecret = await secretsClient.send(
      new GetSecretValueCommand({
        SecretId: `${secretPrefix}/${secretName}`,
      })
    );
    return platformSecret.SecretString || null;
  } catch {
    return null;
  }
}

/**
 * Helper to save secret to org-specific path
 */
async function saveOrgSecret(
  orgId: string,
  secretName: string,
  secretValue: string,
  secretPrefix: string,
  description: string
): Promise<void> {
  const secretPath = `${secretPrefix}/orgs/${orgId}/${secretName}`;

  try {
    await secretsClient.send(
      new PutSecretValueCommand({
        SecretId: secretPath,
        SecretString: secretValue,
      })
    );
  } catch (error) {
    if (error instanceof ResourceNotFoundException) {
      await secretsClient.send(
        new CreateSecretCommand({
          Name: secretPath,
          SecretString: secretValue,
          Description: description,
        })
      );
    } else {
      throw error;
    }
  }
}

/**
 * GET /api/settings/integrations
 * Get integration status (whether credentials are configured)
 */
router.get("/integrations", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const secretPrefix = `workermill/${config.environment}`;

    // Check if secrets exist (without exposing values)
    let jiraConfigured = false;
    let githubConfigured = false;
    let linearConfigured = false;
    let jiraBaseUrl = "";
    let jiraEmail = "";  // Not sensitive - can be returned
    const githubDefaultRepo = org.defaultGithubRepo || "";

    // Check Jira (org-specific with fallback)
    const jiraSecret = await getOrgSecret(org.id, "jira-credentials", secretPrefix);
    if (jiraSecret) {
      try {
        const jiraCreds = JSON.parse(jiraSecret);
        jiraConfigured = !!(jiraCreds.api_token && jiraCreds.email);
        jiraBaseUrl = jiraCreds.base_url || jiraCreds.domain || "";
        jiraEmail = jiraCreds.email || "";
      } catch {
        logger.debug("Failed to parse Jira credentials");
      }
    }

    // Check GitHub (org-specific with fallback)
    const githubSecret = await getOrgSecret(org.id, "github-token", secretPrefix);
    githubConfigured = !!githubSecret;

    // Check GitHub reviewer token (separate token for PR approvals)
    // Check org-specific and platform-wide github-reviewer-token, plus legacy manager-github-token
    let githubReviewerConfigured = false;
    const githubReviewerSecret = await getOrgSecret(org.id, "github-reviewer-token", secretPrefix);
    githubReviewerConfigured = !!githubReviewerSecret;
    // Note: Legacy manager-github-token fallback removed for multi-tenancy security

    // Check GitLab
    const gitlabSecret = await getOrgSecret(org.id, "gitlab-token", secretPrefix);
    const gitlabConfigured = !!gitlabSecret;

    // Check BitBucket
    let bitbucketConfigured = false;
    let bitbucketUsername = "";
    const bitbucketSecret = await getOrgSecret(org.id, "bitbucket-token", secretPrefix);
    if (bitbucketSecret) {
      try {
        const bbCreds = JSON.parse(bitbucketSecret);
        // Support both key formats: username/app_password OR email/api_token
        const hasCredentials =
          (bbCreds.username && bbCreds.app_password) || (bbCreds.email && bbCreds.api_token);
        bitbucketConfigured = !!hasCredentials;
        bitbucketUsername = bbCreds.username || bbCreds.email || "";
      } catch {
        // Plain string format (username:password) is also valid
        bitbucketConfigured = bitbucketSecret.includes(":");
        if (bitbucketConfigured) {
          bitbucketUsername = bitbucketSecret.split(":")[0];
        }
      }
    }

    // Check Linear (org-specific with fallback)
    let linearWorkspace = "";
    const linearSecret = await getOrgSecret(org.id, "linear-credentials", secretPrefix);
    if (linearSecret) {
      try {
        const linearCreds = JSON.parse(linearSecret);
        linearConfigured = !!(linearCreds.api_key || linearCreds.webhook_secret);
        linearWorkspace = linearCreds.workspace || "";
      } catch {
        logger.debug("Failed to parse Linear credentials");
      }
    }

    // Check Teams webhook
    const teamsSecret = await getOrgSecret(org.id, "teams-webhook", secretPrefix);
    const teamsConfigured = !!teamsSecret;

    // Check Slack webhook
    const slackSecret = await getOrgSecret(org.id, "slack-webhook", secretPrefix);
    const slackConfigured = !!slackSecret;

    // Check OnCallShift credentials
    let oncallshiftConfigured = false;
    const oncallshiftSecret = await getOrgSecret(org.id, "oncallshift-credentials", secretPrefix);
    if (oncallshiftSecret) {
      try {
        const oncallshiftCreds = JSON.parse(oncallshiftSecret);
        oncallshiftConfigured = !!oncallshiftCreds.api_key;
      } catch {
        logger.debug("Failed to parse OnCallShift credentials");
      }
    }

    // Check AWS credentials (legacy static credentials)
    let awsConfigured = false;
    const awsSecret = await getOrgSecret(org.id, "aws-credentials", secretPrefix);
    if (awsSecret) {
      try {
        const awsCreds = JSON.parse(awsSecret);
        awsConfigured = !!(awsCreds.access_key_id && awsCreds.secret_access_key);
      } catch {
        logger.debug("Failed to parse AWS credentials");
      }
    }

    // Check AWS cross-account role config (secure role assumption)
    let awsRoleConfigured = false;
    let awsRoleArn = "";
    let awsExternalId = "";
    try {
      const roleConfig = await getAwsRoleConfig(org.id);
      if (roleConfig && roleConfig.roleArn) {
        awsRoleConfigured = true;
        awsRoleArn = roleConfig.roleArn;
        awsExternalId = roleConfig.externalId;
      } else {
        // Generate external ID even if role not configured yet
        awsExternalId = await getOrCreateExternalId(org.id);
      }
    } catch {
      logger.debug("Failed to get AWS role config");
    }

    // Check GCP credentials
    let gcpConfigured = false;
    const gcpSecret = await getOrgSecret(org.id, "gcp-credentials", secretPrefix);
    if (gcpSecret) {
      try {
        const gcpCreds = JSON.parse(gcpSecret);
        gcpConfigured = !!(gcpCreds.project_id && gcpCreds.service_account);
      } catch {
        logger.debug("Failed to parse GCP credentials");
      }
    }

    // Check Azure credentials
    let azureConfigured = false;
    const azureSecret = await getOrgSecret(org.id, "azure-credentials", secretPrefix);
    if (azureSecret) {
      try {
        const azureCreds = JSON.parse(azureSecret);
        azureConfigured = !!(azureCreds.client_id && azureCreds.client_secret && azureCreds.tenant_id);
      } catch {
        logger.debug("Failed to parse Azure credentials");
      }
    }

    res.json({
      defaultIssueTracker: org.issueTrackerProvider || "jira",
      jira: {
        configured: jiraConfigured,
        baseUrl: jiraBaseUrl,
        email: jiraEmail,
        webhookSecretConfigured: !!org.jiraWebhookSecret,
      },
      github: {
        configured: githubConfigured,
        defaultRepo: githubDefaultRepo,
        webhookSecretConfigured: !!org.githubWebhookSecret,
        reviewerTokenConfigured: githubReviewerConfigured,
      },
      gitlab: {
        configured: gitlabConfigured,
        defaultRepo: org.defaultGitlabRepo || "",
      },
      bitbucket: {
        configured: bitbucketConfigured,
        username: bitbucketUsername,
        defaultRepo: org.defaultBitbucketRepo || "",
        webhookSecretConfigured: !!org.bitbucketWebhookSecret,
      },
      linear: {
        configured: linearConfigured,
        workspace: linearWorkspace,
        webhookSecretConfigured: !!(org.providerSettings as Record<string, unknown>)?.linearWebhookSecret,
      },
      slack: {
        configured: slackConfigured,
      },
      teams: {
        configured: teamsConfigured,
      },
      oncallshift: {
        configured: oncallshiftConfigured,
      },
      aws: {
        configured: awsConfigured,
        roleConfigured: awsRoleConfigured,
        roleArn: awsRoleArn || null,
        externalId: awsExternalId || null,
      },
      gcp: {
        configured: gcpConfigured,
      },
      azure: {
        configured: azureConfigured,
      },
    });
  } catch (error) {
    logger.error("Error getting integration status", { error });
    res.status(500).json({ error: "Failed to get integration status" });
  }
});

/**
 * PUT /api/settings/integrations/jira
 * Save Jira credentials to Secrets Manager (org-specific)
 * Supports partial updates by merging with existing credentials
 */
router.put(
  "/integrations/jira",
  requireAdmin,
  body("baseUrl").optional().isURL().withMessage("baseUrl must be a valid URL"),
  body("email").optional().isEmail().withMessage("email must be a valid email address"),
  body("apiToken").optional().isString().withMessage("apiToken must be a string"),
  body("webhookSecret").optional().isString().withMessage("webhookSecret must be a string"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const { baseUrl, email, apiToken, webhookSecret } = req.body;
      const org = req.organization!;
      const secretPrefix = `workermill/${config.environment}`;

      // Require at least one field to update
      if (!baseUrl && !email && !apiToken && !webhookSecret) {
        res.status(400).json({ error: "At least one field is required" });
        return;
      }

      let credentialsUpdated = false;

      // Handle API credentials (merge with existing if partial update)
      if (baseUrl || email || apiToken) {
        // Fetch existing credentials to merge
        let existingCreds: { base_url?: string; email?: string; api_token?: string } = {};
        const existingSecret = await getOrgSecret(org.id, "jira-credentials", secretPrefix);
        if (existingSecret) {
          try {
            existingCreds = JSON.parse(existingSecret);
          } catch {
            // Ignore parse errors - start fresh
          }
        }

        // Merge new values with existing
        const mergedCreds = {
          base_url: baseUrl || existingCreds.base_url || "",
          email: email || existingCreds.email || "",
          api_token: apiToken || existingCreds.api_token || "",
        };

        // Only save if we have all required fields after merge
        if (mergedCreds.base_url && mergedCreds.email && mergedCreds.api_token) {
          const jiraCredentials = JSON.stringify(mergedCreds);

          await saveOrgSecret(
            org.id,
            "jira-credentials",
            jiraCredentials,
            secretPrefix,
            `Jira credentials for org ${org.id}`
          );
          logger.info("Jira API credentials updated", { orgId: org.id });
          credentialsUpdated = true;
        } else {
          // Return error if trying to save incomplete credentials
          const missing = [];
          if (!mergedCreds.base_url) missing.push("Base URL");
          if (!mergedCreds.email) missing.push("Email");
          if (!mergedCreds.api_token) missing.push("API Token");

          res.status(400).json({
            error: `Incomplete Jira credentials. Missing: ${missing.join(", ")}`,
            hint: "All three fields (Base URL, Email, API Token) are required for API access"
          });
          return;
        }
      }

      // Save webhook secret to organization table if provided
      if (webhookSecret) {
        const orgRepo = AppDataSource.getRepository(Organization);
        await orgRepo.update(org.id, { jiraWebhookSecret: webhookSecret });
        logger.info("Jira webhook secret updated", { orgId: org.id });
      }

      res.json({
        success: true,
        message: "Jira settings saved successfully",
        credentialsUpdated,
        webhookSecretUpdated: !!webhookSecret
      });
    } catch (error) {
      logger.error("Error saving Jira credentials", { error });
      res.status(500).json({ error: "Failed to save Jira credentials" });
    }
  }
);

/**
 * PUT /api/settings/integrations/github
 * Save GitHub token to Secrets Manager (org-specific) and/or default repo to org
 * Token is optional if only updating the default repo
 */
router.put(
  "/integrations/github",
  requireAdmin,
  body("token").optional().isString().withMessage("token must be a string"),
  body("reviewerToken").optional().isString().withMessage("reviewerToken must be a string"),
  body("defaultRepo").optional().isString().withMessage("defaultRepo must be a string"),
  body("webhookSecret").optional().isString().withMessage("webhookSecret must be a string"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const { token, reviewerToken, defaultRepo, webhookSecret } = req.body;
      const org = req.organization!;

      // Require at least one field to update
      if (!token && !reviewerToken && defaultRepo === undefined && !webhookSecret) {
        res.status(400).json({ error: "At least one field is required" });
        return;
      }

      const secretPrefix = `workermill/${config.environment}`;

      // Save token to org-specific path in Secrets Manager if provided
      if (token) {
        await saveOrgSecret(
          org.id,
          "github-token",
          token,
          secretPrefix,
          `GitHub token for org ${org.id}`
        );
      }

      // Save reviewer token to org-specific path in Secrets Manager if provided
      // This separate token is used for PR approvals to avoid GitHub's self-approval restriction
      if (reviewerToken) {
        await saveOrgSecret(
          org.id,
          "github-reviewer-token",
          reviewerToken,
          secretPrefix,
          `GitHub reviewer token for org ${org.id} (PR approvals)`
        );
      }

      // Save default repo and/or webhook secret to organization if provided
      if (defaultRepo !== undefined || webhookSecret) {
        const orgRepo = AppDataSource.getRepository(Organization);
        if (defaultRepo !== undefined) {
          org.defaultGithubRepo = defaultRepo;
        }
        if (webhookSecret) {
          org.githubWebhookSecret = webhookSecret;
        }
        await orgRepo.save(org);
      }

      logger.info("GitHub settings updated", {
        orgId: org.id,
        tokenUpdated: !!token,
        reviewerTokenUpdated: !!reviewerToken,
        repoUpdated: defaultRepo !== undefined,
        webhookSecretUpdated: !!webhookSecret,
      });

      res.json({ success: true, message: "GitHub settings saved successfully" });
    } catch (error) {
      logger.error("Error saving GitHub credentials", { error });
      res.status(500).json({ error: "Failed to save GitHub credentials" });
    }
  }
);

/**
 * POST /api/settings/integrations/jira/test
 * Test Jira connection (uses org-specific with fallback)
 */
router.post("/integrations/jira/test", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const secretPrefix = `workermill/${config.environment}`;

    // Get Jira credentials (org-specific with fallback)
    const jiraSecretString = await getOrgSecret(org.id, "jira-credentials", secretPrefix);

    if (!jiraSecretString) {
      res.status(400).json({ error: "Jira credentials not configured" });
      return;
    }

    const jiraCreds = JSON.parse(jiraSecretString);
    const { base_url, email, api_token } = jiraCreds;

    if (!base_url || !email || !api_token) {
      res.status(400).json({ error: "Incomplete Jira credentials" });
      return;
    }

    // Test connection by fetching current user
    const authHeader = Buffer.from(`${email}:${api_token}`).toString("base64");
    const response = await fetch(`${base_url}/rest/api/3/myself`, {
      headers: {
        Authorization: `Basic ${authHeader}`,
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      logger.warn("Jira connection test failed", { status: response.status, error: errorText });
      res.status(400).json({ error: `Jira connection failed: ${response.status}` });
      return;
    }

    const userData = await response.json() as { displayName?: string; emailAddress?: string };
    res.json({
      success: true,
      message: "Jira connection successful",
      user: userData.displayName || userData.emailAddress,
    });
  } catch (error) {
    logger.error("Error testing Jira connection", { error });
    res.status(500).json({ error: "Failed to test Jira connection" });
  }
});

/**
 * POST /api/settings/integrations/github/test
 * Test GitHub connection for both worker token and reviewer token
 */
router.post("/integrations/github/test", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const secretPrefix = `workermill/${config.environment}`;

    // Helper to test a GitHub token
    const testGitHubToken = async (
      token: string | null,
      tokenType: string
    ): Promise<{ success: boolean; user?: string; error?: string }> => {
      if (!token) {
        return { success: false, error: "Not configured" };
      }

      try {
        const response = await fetch("https://api.github.com/user", {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/vnd.github.v3+json",
          },
        });

        if (!response.ok) {
          const errorText = await response.text();
          logger.warn(`GitHub ${tokenType} test failed`, { status: response.status, error: errorText });
          return { success: false, error: `HTTP ${response.status}` };
        }

        const userData = (await response.json()) as { login?: string };
        return { success: true, user: userData.login };
      } catch (err) {
        return { success: false, error: err instanceof Error ? err.message : "Unknown error" };
      }
    };

    // Get both tokens
    const workerToken = await getOrgSecret(org.id, "github-token", secretPrefix);
    const reviewerToken = await getOrgSecret(org.id, "github-reviewer-token", secretPrefix);

    // Test both tokens in parallel
    const [workerResult, reviewerResult] = await Promise.all([
      testGitHubToken(workerToken, "worker token"),
      testGitHubToken(reviewerToken, "reviewer token"),
    ]);

    // Determine overall success (at least worker token must work)
    const overallSuccess = workerResult.success;

    res.json({
      success: overallSuccess,
      message: overallSuccess ? "GitHub connection successful" : "GitHub worker token failed",
      workerToken: {
        configured: !!workerToken,
        success: workerResult.success,
        user: workerResult.user,
        error: workerResult.error,
      },
      reviewerToken: {
        configured: !!reviewerToken,
        success: reviewerResult.success,
        user: reviewerResult.user,
        error: reviewerResult.error,
      },
    });
  } catch (error) {
    logger.error("Error testing GitHub connection", { error });
    res.status(500).json({ error: "Failed to test GitHub connection" });
  }
});

/**
 * POST /api/settings/integrations/gitlab/test
 * Test GitLab connection using stored credentials
 */
router.post("/integrations/gitlab/test", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const secretPrefix = `workermill/${config.environment}`;

    // Get GitLab token from Secrets Manager
    const gitlabToken = await getOrgSecret(org.id, "gitlab-token", secretPrefix);

    if (!gitlabToken) {
      res.status(400).json({ error: "GitLab token not configured" });
      return;
    }

    // Get base URL from org settings (for self-hosted instances)
    const baseUrl = org.scmBaseUrl && org.scmProvider === "gitlab"
      ? `${org.scmBaseUrl.replace(/\/$/, "")}/api/v4`
      : "https://gitlab.com/api/v4";

    // Test by fetching current user
    const response = await fetch(`${baseUrl}/user`, {
      headers: {
        "PRIVATE-TOKEN": gitlabToken,
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      logger.warn("GitLab test failed", { status: response.status, error: errorText });
      res.json({
        success: false,
        error: `HTTP ${response.status}: ${errorText.substring(0, 100)}`,
      });
      return;
    }

    const userData = (await response.json()) as { username?: string; name?: string };
    res.json({
      success: true,
      message: "GitLab connection successful",
      user: userData.username || userData.name,
    });
  } catch (error) {
    logger.error("Error testing GitLab connection", { error });
    res.status(500).json({ error: "Failed to test GitLab connection" });
  }
});

/**
 * POST /api/settings/integrations/bitbucket/test
 * Test BitBucket connection using stored credentials
 */
router.post("/integrations/bitbucket/test", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const secretPrefix = `workermill/${config.environment}`;

    // Get BitBucket credentials from Secrets Manager
    // Expected format: { "username": "...", "app_password": "..." } or plain "username:password"
    const bitbucketSecret = await getOrgSecret(org.id, "bitbucket-token", secretPrefix);

    if (!bitbucketSecret) {
      res.status(400).json({ error: "BitBucket credentials not configured" });
      return;
    }

    // Parse credentials - support both key formats
    let authString: string;
    try {
      const creds = JSON.parse(bitbucketSecret) as {
        username?: string;
        app_password?: string;
        email?: string;
        api_token?: string;
      };
      if (creds.username && creds.app_password) {
        authString = `${creds.username}:${creds.app_password}`;
      } else if (creds.email && creds.api_token) {
        authString = `${creds.email}:${creds.api_token}`;
      } else {
        authString = bitbucketSecret;
      }
    } catch {
      // Plain string format: "username:password"
      authString = bitbucketSecret;
    }

    // Test by fetching current user
    const response = await fetch("https://api.bitbucket.org/2.0/user", {
      headers: {
        Authorization: `Basic ${Buffer.from(authString).toString("base64")}`,
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      logger.warn("BitBucket test failed", { status: response.status, error: errorText });
      res.json({
        success: false,
        error: `HTTP ${response.status}: ${errorText.substring(0, 100)}`,
      });
      return;
    }

    const userData = (await response.json()) as { username?: string; display_name?: string };
    res.json({
      success: true,
      message: "BitBucket connection successful",
      user: userData.display_name || userData.username,
    });
  } catch (error) {
    logger.error("Error testing BitBucket connection", { error });
    res.status(500).json({ error: "Failed to test BitBucket connection" });
  }
});

/**
 * PUT /api/settings/integrations/gitlab
 * Save GitLab credentials to Secrets Manager (org-specific)
 */
router.put(
  "/integrations/gitlab",
  requireAdmin,
  body("token").optional().isString().withMessage("token must be a string"),
  body("webhookSecret").optional().isString().withMessage("webhookSecret must be a string"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const { token, webhookSecret } = req.body;
      const org = req.organization!;

      // Require at least one field to update
      if (!token && !webhookSecret) {
        res.status(400).json({ error: "At least one field is required (token or webhookSecret)" });
        return;
      }

      const secretPrefix = `workermill/${config.environment}`;

      // Save token to org-specific path in Secrets Manager if provided
      if (token) {
        await saveOrgSecret(
          org.id,
          "gitlab-token",
          token,
          secretPrefix,
          `GitLab token for org ${org.id}`
        );
      }

      // Save webhook secret to organization if provided
      if (webhookSecret) {
        const orgRepo = AppDataSource.getRepository(Organization);
        org.gitlabWebhookSecret = webhookSecret;
        await orgRepo.save(org);
      }

      logger.info("GitLab settings updated", {
        orgId: org.id,
        tokenUpdated: !!token,
        webhookSecretUpdated: !!webhookSecret,
      });

      res.json({ success: true, message: "GitLab settings saved successfully" });
    } catch (error) {
      logger.error("Error saving GitLab credentials", { error });
      res.status(500).json({ error: "Failed to save GitLab credentials" });
    }
  }
);

/**
 * PUT /api/settings/integrations/bitbucket
 * Save BitBucket credentials to Secrets Manager (org-specific)
 */
router.put(
  "/integrations/bitbucket",
  requireAdmin,
  body("username").optional().isString().withMessage("username must be a string"),
  body("appPassword").optional().isString().withMessage("appPassword must be a string"),
  body("defaultRepo").optional().isString().withMessage("defaultRepo must be a string"),
  body("webhookSecret").optional().isString().withMessage("webhookSecret must be a string"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const { username, appPassword, defaultRepo, webhookSecret } = req.body;
      const org = req.organization!;

      // Require at least one field to update
      if (!username && !appPassword && defaultRepo === undefined && !webhookSecret) {
        res.status(400).json({ error: "At least one field is required (username, appPassword, defaultRepo, or webhookSecret)" });
        return;
      }

      const secretPrefix = `workermill/${config.environment}`;

      // Save credentials to org-specific path in Secrets Manager if provided
      if (username || appPassword) {
        // Get existing credentials to merge
        let existingCreds: { username?: string; app_password?: string } = {};
        const existingSecret = await getOrgSecret(org.id, "bitbucket-token", secretPrefix);
        if (existingSecret) {
          try {
            existingCreds = JSON.parse(existingSecret);
          } catch {
            // Plain string format - parse username:password
            const parts = existingSecret.split(":");
            if (parts.length === 2) {
              existingCreds = { username: parts[0], app_password: parts[1] };
            }
          }
        }

        // Merge with new values
        const newCreds = {
          username: username || existingCreds.username || "",
          app_password: appPassword || existingCreds.app_password || "",
        };

        await saveOrgSecret(
          org.id,
          "bitbucket-token",
          JSON.stringify(newCreds),
          secretPrefix,
          `BitBucket credentials for org ${org.id}`
        );
      }

      // Save default repo and/or webhook secret to organization if provided
      if (defaultRepo !== undefined || webhookSecret) {
        const orgRepo = AppDataSource.getRepository(Organization);
        if (defaultRepo !== undefined) {
          org.defaultBitbucketRepo = defaultRepo;
        }
        if (webhookSecret) {
          org.bitbucketWebhookSecret = webhookSecret;
        }
        await orgRepo.save(org);
      }

      logger.info("BitBucket settings updated", {
        orgId: org.id,
        credentialsUpdated: !!(username || appPassword),
        repoUpdated: defaultRepo !== undefined,
        webhookSecretUpdated: !!webhookSecret,
      });

      res.json({ success: true, message: "BitBucket settings saved successfully" });
    } catch (error) {
      logger.error("Error saving BitBucket credentials", { error });
      res.status(500).json({ error: "Failed to save BitBucket credentials" });
    }
  }
);

/**
 * POST /api/settings/integrations/github/migrate-reviewer-token
 * Migrate the legacy manager-github-token to the new org-specific github-reviewer-token path.
 * This is a one-time migration utility for moving from the old platform-wide token to org-specific storage.
 */
router.post("/integrations/github/migrate-reviewer-token", requireAdmin, async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const secretPrefix = `workermill/${config.environment}`;
    const { cleanupLegacy } = req.body;

    // Check if org-specific token already exists
    const orgSpecificPath = `${secretPrefix}/orgs/${org.id}/github-reviewer-token`;
    let orgTokenExists = false;
    try {
      const existingOrgSecret = await secretsClient.send(
        new GetSecretValueCommand({ SecretId: orgSpecificPath })
      );
      orgTokenExists = !!existingOrgSecret.SecretString;
    } catch {
      // Not found, will migrate
    }

    if (orgTokenExists) {
      res.json({
        success: true,
        migrated: false,
        message: "Org-specific reviewer token already exists, no migration needed",
        orgSpecificPath,
      });
      return;
    }

    // Try to get the legacy manager-github-token
    const legacyPath = `${secretPrefix}/manager-github-token`;
    let legacyToken: string | null = null;
    try {
      const legacySecret = await secretsClient.send(
        new GetSecretValueCommand({ SecretId: legacyPath })
      );
      legacyToken = legacySecret.SecretString || null;
    } catch {
      // Not found
    }

    if (!legacyToken) {
      res.status(404).json({
        error: "No legacy manager-github-token found to migrate",
        legacyPath,
      });
      return;
    }

    // Save to org-specific path
    await saveOrgSecret(
      org.id,
      "github-reviewer-token",
      legacyToken,
      secretPrefix,
      `GitHub reviewer token for org ${org.id} (migrated from manager-github-token)`
    );

    logger.info("Migrated reviewer token to org-specific path", {
      orgId: org.id,
      from: legacyPath,
      to: orgSpecificPath,
    });

    // Optionally clean up the legacy secret
    let legacyDeleted = false;
    if (cleanupLegacy === true) {
      try {
        await secretsClient.send(
          new DeleteSecretCommand({
            SecretId: legacyPath,
            ForceDeleteWithoutRecovery: false, // Allow recovery for 30 days
          })
        );
        legacyDeleted = true;
        logger.info("Deleted legacy manager-github-token", { path: legacyPath });
      } catch (deleteError) {
        logger.warn("Failed to delete legacy secret", { path: legacyPath, error: deleteError });
      }
    }

    res.json({
      success: true,
      migrated: true,
      message: `Reviewer token migrated to org-specific path${legacyDeleted ? " and legacy secret scheduled for deletion" : ""}`,
      from: legacyPath,
      to: orgSpecificPath,
      legacyDeleted,
    });
  } catch (error) {
    logger.error("Error migrating reviewer token", { error });
    res.status(500).json({ error: "Failed to migrate reviewer token" });
  }
});

/**
 * PUT /api/settings/integrations/linear
 * Save Linear credentials to Secrets Manager (org-specific)
 */
router.put(
  "/integrations/linear",
  requireAdmin,
  body("apiKey").optional().isString().withMessage("apiKey must be a string"),
  body("webhookSecret").optional().isString().withMessage("webhookSecret must be a string"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const { apiKey, webhookSecret } = req.body;
      const org = req.organization!;
      const secretPrefix = `workermill/${config.environment}`;

      // Require at least one field
      if (!apiKey && !webhookSecret) {
        res.status(400).json({ error: "At least one of apiKey or webhookSecret is required" });
        return;
      }

      // Get existing credentials to merge
      let existingCreds: { api_key?: string; webhook_secret?: string; workspace?: string } = {};
      const existingSecret = await getOrgSecret(org.id, "linear-credentials", secretPrefix);
      if (existingSecret) {
        try {
          existingCreds = JSON.parse(existingSecret);
        } catch {
          // Ignore parse errors
        }
      }

      // If API key is provided, fetch the organization workspace URL key
      let workspace = existingCreds.workspace || "";
      if (apiKey) {
        try {
          const orgResponse = await fetch("https://api.linear.app/graphql", {
            method: "POST",
            headers: {
              Authorization: apiKey,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              query: `query { organization { urlKey } }`,
            }),
          });
          if (orgResponse.ok) {
            const orgData = (await orgResponse.json()) as { data?: { organization?: { urlKey?: string } } };
            if (orgData.data?.organization?.urlKey) {
              workspace = orgData.data.organization.urlKey;
              logger.info("Fetched Linear workspace URL key", { orgId: org.id, workspace });
            }
          }
        } catch (e) {
          logger.warn("Failed to fetch Linear workspace URL key", { error: e });
        }
      }

      // Merge with new values
      const linearCredentials = JSON.stringify({
        api_key: apiKey || existingCreds.api_key || "",
        webhook_secret: webhookSecret || existingCreds.webhook_secret || "",
        workspace,
      });

      await saveOrgSecret(
        org.id,
        "linear-credentials",
        linearCredentials,
        secretPrefix,
        `Linear credentials for org ${org.id}`
      );

      // Also update the org's providerSettings for webhook verification
      if (webhookSecret) {
        const orgRepo = AppDataSource.getRepository(Organization);
        const providerSettings = (org.providerSettings as Record<string, unknown>) || {};
        providerSettings.linearWebhookSecret = webhookSecret;
        org.providerSettings = providerSettings;
        await orgRepo.save(org);
      }

      logger.info("Linear credentials updated", { orgId: org.id });

      res.json({ success: true, message: "Linear credentials saved successfully" });
    } catch (error) {
      logger.error("Error saving Linear credentials", { error });
      res.status(500).json({ error: "Failed to save Linear credentials" });
    }
  }
);

/**
 * POST /api/settings/integrations/linear/test
 * Test Linear connection (uses org-specific with fallback)
 */
router.post("/integrations/linear/test", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const secretPrefix = `workermill/${config.environment}`;

    // Get Linear credentials (org-specific with fallback)
    const linearSecretString = await getOrgSecret(org.id, "linear-credentials", secretPrefix);

    if (!linearSecretString) {
      res.status(400).json({ error: "Linear credentials not configured" });
      return;
    }

    const linearCreds = JSON.parse(linearSecretString);
    const { api_key } = linearCreds;

    if (!api_key) {
      res.status(400).json({ error: "Linear API key not configured" });
      return;
    }

    // Test connection by fetching current user via GraphQL
    const response = await fetch("https://api.linear.app/graphql", {
      method: "POST",
      headers: {
        Authorization: api_key,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query: `query { viewer { id name email } }`,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      logger.warn("Linear connection test failed", { status: response.status, error: errorText });
      res.status(400).json({ error: `Linear connection failed: ${response.status}` });
      return;
    }

    const data = (await response.json()) as { data?: { viewer?: { name?: string; email?: string } }; errors?: Array<{ message: string }> };

    if (data.errors && data.errors.length > 0) {
      logger.warn("Linear API error", { errors: data.errors });
      res.status(400).json({ error: `Linear API error: ${data.errors[0].message}` });
      return;
    }

    res.json({
      success: true,
      message: "Linear connection successful",
      user: data.data?.viewer?.name || data.data?.viewer?.email,
    });
  } catch (error) {
    logger.error("Error testing Linear connection", { error });
    res.status(500).json({ error: "Failed to test Linear connection" });
  }
});

/**
 * GET /api/settings/integrations/linear/teams
 * Get Linear teams for issue creation
 */
router.get("/integrations/linear/teams", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const { getLinearTeams } = await import("../utils/linear.js");
    const teams = await getLinearTeams(org.id);
    if (!teams) {
      res.status(400).json({ error: "Failed to fetch Linear teams" });
      return;
    }
    res.json({ teams });
  } catch (error) {
    logger.error("Error fetching Linear teams", { error });
    res.status(500).json({ error: "Failed to fetch Linear teams" });
  }
});

/**
 * GET /api/settings/integrations/linear/labels
 * Get Linear labels for issue creation
 */
router.get("/integrations/linear/labels", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const teamId = req.query.teamId as string | undefined;
    const { getLinearLabels } = await import("../utils/linear.js");
    const labels = await getLinearLabels(org.id, teamId);
    if (!labels) {
      res.status(400).json({ error: "Failed to fetch Linear labels" });
      return;
    }
    res.json({ labels });
  } catch (error) {
    logger.error("Error fetching Linear labels", { error });
    res.status(500).json({ error: "Failed to fetch Linear labels" });
  }
});

/**
 * POST /api/settings/integrations/linear/issues
 * Create a Linear issue (for testing)
 */
router.post("/integrations/linear/issues", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const { teamId, title, description, labelIds } = req.body;

    if (!teamId || !title) {
      res.status(400).json({ error: "teamId and title are required" });
      return;
    }

    const { createLinearIssue } = await import("../utils/linear.js");
    const issue = await createLinearIssue(org.id, teamId, title, description, labelIds);

    if (!issue) {
      res.status(500).json({ error: "Failed to create Linear issue" });
      return;
    }

    logger.info("Created Linear issue via API", { orgId: org.id, issue });
    res.json({ success: true, issue });
  } catch (error) {
    logger.error("Error creating Linear issue", { error });
    res.status(500).json({ error: "Failed to create Linear issue" });
  }
});

// =============================================================================
// Teams Integration
// =============================================================================

/**
 * PUT /api/settings/integrations/teams
 * Save Teams webhook URL to Secrets Manager (org-specific)
 */
router.put(
  "/integrations/teams",
  requireAdmin,
  body("webhookUrl").isURL().withMessage("webhookUrl must be a valid URL"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const { webhookUrl } = req.body;
      const org = req.organization!;
      const secretPrefix = `workermill/${config.environment}`;

      await saveOrgSecret(
        org.id,
        "teams-webhook",
        webhookUrl,
        secretPrefix,
        `Teams webhook URL for org ${org.id}`
      );

      logger.info("Teams webhook URL updated", { orgId: org.id });

      res.json({ success: true, message: "Teams webhook saved successfully" });
    } catch (error) {
      logger.error("Error saving Teams webhook", { error });
      res.status(500).json({ error: "Failed to save Teams webhook" });
    }
  }
);

/**
 * POST /api/settings/integrations/teams/test
 * Test Teams webhook by sending a test message
 */
router.post("/integrations/teams/test", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const secretPrefix = `workermill/${config.environment}`;

    const webhookUrl = await getOrgSecret(org.id, "teams-webhook", secretPrefix);

    if (!webhookUrl) {
      res.status(400).json({ error: "Teams webhook not configured" });
      return;
    }

    // Send test message to Teams
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        "@type": "MessageCard",
        "@context": "http://schema.org/extensions",
        themeColor: "0076D7",
        summary: "WorkerMill Test Message",
        sections: [{
          activityTitle: "WorkerMill Notification Test",
          activitySubtitle: `Test from ${org.name}`,
          activityImage: "https://workermill.com/favicon.ico",
          facts: [{
            name: "Status",
            value: "Connection successful"
          }, {
            name: "Time",
            value: new Date().toISOString()
          }],
          markdown: true
        }]
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      logger.warn("Teams webhook test failed", { status: response.status, error: errorText });
      res.status(400).json({ error: `Teams webhook failed: ${response.status}` });
      return;
    }

    res.json({
      success: true,
      message: "Teams webhook test successful! Check your Teams channel.",
    });
  } catch (error) {
    logger.error("Error testing Teams webhook", { error });
    res.status(500).json({ error: "Failed to test Teams webhook" });
  }
});

// =============================================================================
// Slack Integration
// =============================================================================

/**
 * PUT /api/settings/integrations/slack
 * Save Slack webhook URL to Secrets Manager (org-specific)
 */
router.put(
  "/integrations/slack",
  requireAdmin,
  body("webhookUrl").isURL().withMessage("webhookUrl must be a valid URL"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const { webhookUrl } = req.body;
      const org = req.organization!;
      const secretPrefix = `workermill/${config.environment}`;

      await saveOrgSecret(
        org.id,
        "slack-webhook",
        webhookUrl,
        secretPrefix,
        `Slack webhook URL for org ${org.id}`
      );

      logger.info("Slack webhook URL updated", { orgId: org.id });

      res.json({ success: true, message: "Slack webhook saved successfully" });
    } catch (error) {
      logger.error("Error saving Slack webhook", { error });
      res.status(500).json({ error: "Failed to save Slack webhook" });
    }
  }
);

/**
 * POST /api/settings/integrations/slack/test
 * Test Slack webhook by sending a test message
 */
router.post("/integrations/slack/test", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const secretPrefix = `workermill/${config.environment}`;

    const webhookUrl = await getOrgSecret(org.id, "slack-webhook", secretPrefix);

    if (!webhookUrl) {
      res.status(400).json({ error: "Slack webhook not configured" });
      return;
    }

    // Send test message to Slack
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text: "WorkerMill Notification Test",
        blocks: [
          {
            type: "header",
            text: {
              type: "plain_text",
              text: "🔧 WorkerMill Notification Test",
              emoji: true
            }
          },
          {
            type: "section",
            fields: [
              {
                type: "mrkdwn",
                text: `*Organization:*\n${org.name}`
              },
              {
                type: "mrkdwn",
                text: `*Status:*\n✅ Connection successful`
              }
            ]
          },
          {
            type: "context",
            elements: [
              {
                type: "mrkdwn",
                text: `Sent at ${new Date().toISOString()}`
              }
            ]
          }
        ]
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      logger.warn("Slack webhook test failed", { status: response.status, error: errorText });
      res.status(400).json({ error: `Slack webhook failed: ${response.status}` });
      return;
    }

    res.json({
      success: true,
      message: "Slack webhook test successful! Check your Slack channel.",
    });
  } catch (error) {
    logger.error("Error testing Slack webhook", { error });
    res.status(500).json({ error: "Failed to test Slack webhook" });
  }
});

// =============================================================================
// Cloud Provider Integrations
// =============================================================================

/**
 * PUT /api/settings/integrations/aws
 * Save AWS credentials to Secrets Manager (org-specific)
 */
router.put(
  "/integrations/aws",
  requireAdmin,
  body("accessKeyId").isString().notEmpty().withMessage("accessKeyId is required"),
  body("secretAccessKey").isString().notEmpty().withMessage("secretAccessKey is required"),
  body("region").optional().isString().withMessage("region must be a string"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const { accessKeyId, secretAccessKey, region } = req.body;
      const org = req.organization!;
      const secretPrefix = `workermill/${config.environment}`;

      const awsCredentials = JSON.stringify({
        access_key_id: accessKeyId,
        secret_access_key: secretAccessKey,
        region: region || "us-east-1",
      });

      await saveOrgSecret(
        org.id,
        "aws-credentials",
        awsCredentials,
        secretPrefix,
        `AWS credentials for org ${org.id}`
      );

      logger.info("AWS credentials updated", { orgId: org.id });

      res.json({ success: true, message: "AWS credentials saved successfully" });
    } catch (error) {
      logger.error("Error saving AWS credentials", { error });
      res.status(500).json({ error: "Failed to save AWS credentials" });
    }
  }
);

/**
 * POST /api/settings/integrations/aws/test
 * Test AWS credentials by calling STS GetCallerIdentity
 */
router.post("/integrations/aws/test", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const secretPrefix = `workermill/${config.environment}`;

    const awsSecretString = await getOrgSecret(org.id, "aws-credentials", secretPrefix);

    if (!awsSecretString) {
      res.status(400).json({ error: "AWS credentials not configured" });
      return;
    }

    const awsCreds = JSON.parse(awsSecretString);
    const { access_key_id, secret_access_key, region } = awsCreds;

    if (!access_key_id || !secret_access_key) {
      res.status(400).json({ error: "Incomplete AWS credentials" });
      return;
    }

    // Use AWS SDK to test credentials
    const { STSClient, GetCallerIdentityCommand } = await import("@aws-sdk/client-sts");
    const stsClient = new STSClient({
      region: region || "us-east-1",
      credentials: {
        accessKeyId: access_key_id,
        secretAccessKey: secret_access_key,
      },
    });

    const identity = await stsClient.send(new GetCallerIdentityCommand({}));

    res.json({
      success: true,
      message: "AWS connection successful",
      account: identity.Account,
      arn: identity.Arn,
    });
  } catch (error) {
    logger.error("Error testing AWS credentials", { error });
    const message = error instanceof Error ? error.message : "AWS connection failed";
    res.status(400).json({ error: message });
  }
});

// =============================================================================
// AWS Cross-Account Role Configuration (Secure Multi-Cloud Deployment)
// =============================================================================

/**
 * GET /api/settings/integrations/aws/external-id
 * Get or generate the external ID for AWS cross-account role assumption
 * This ID is unique per organization and prevents confused deputy attacks
 */
router.get("/integrations/aws/external-id", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const externalId = await getOrCreateExternalId(org.id);

    res.json({
      externalId,
      usage: "Add this External ID as a condition in your IAM role's trust policy",
      trustPolicyExample: {
        Version: "2012-10-17",
        Statement: [
          {
            Effect: "Allow",
            Principal: {
              AWS: "arn:aws:iam::593971626975:role/workermill-dev-worker-task",
            },
            Action: "sts:AssumeRole",
            Condition: {
              StringEquals: {
                "sts:ExternalId": externalId,
              },
            },
          },
        ],
      },
    });
  } catch (error) {
    logger.error("Error generating external ID", { error });
    res.status(500).json({ error: "Failed to generate external ID" });
  }
});

/**
 * GET /api/settings/integrations/aws/role
 * Get the current AWS role configuration for cross-account deployments
 */
router.get("/integrations/aws/role", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const roleConfig = await getAwsRoleConfig(org.id);

    if (!roleConfig) {
      // Return empty config with just the external ID
      const externalId = await getOrCreateExternalId(org.id);
      res.json({
        configured: false,
        externalId,
        roleArn: null,
        region: null,
      });
      return;
    }

    res.json({
      configured: true,
      externalId: roleConfig.externalId,
      roleArn: roleConfig.roleArn,
      region: roleConfig.region,
      createdAt: roleConfig.createdAt,
      updatedAt: roleConfig.updatedAt,
    });
  } catch (error) {
    logger.error("Error getting AWS role config", { error });
    res.status(500).json({ error: "Failed to get AWS role configuration" });
  }
});

/**
 * PUT /api/settings/integrations/aws/role
 * Configure the IAM role ARN that workers will assume for deployments
 */
router.put(
  "/integrations/aws/role",
  requireAdmin,
  body("roleArn").isString().notEmpty().withMessage("roleArn is required"),
  body("region").optional().isString().withMessage("region must be a string"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const { roleArn, region } = req.body;
      const org = req.organization!;

      // Validate role ARN format
      if (!isValidAwsRoleArn(roleArn)) {
        res.status(400).json({
          error: "Invalid role ARN format",
          hint: "Expected format: arn:aws:iam::{account-id}:role/{role-name}",
        });
        return;
      }

      // Extract and log the target account
      const targetAccount = extractAccountIdFromArn(roleArn);
      logger.info("Configuring AWS role for cross-account access", {
        orgId: org.id,
        roleArn,
        targetAccount,
        region: region || "us-east-1",
      });

      // Save the role configuration
      const roleConfig = await saveAwsRoleConfig(org.id, roleArn, region || "us-east-1");

      res.json({
        success: true,
        message: "AWS role configuration saved",
        config: {
          roleArn: roleConfig.roleArn,
          externalId: roleConfig.externalId,
          region: roleConfig.region,
          updatedAt: roleConfig.updatedAt,
        },
        nextSteps: [
          "Ensure the IAM role exists in your AWS account",
          "The role must trust WorkerMill's worker role as a principal",
          "The role's trust policy must require the external ID: " + roleConfig.externalId,
          "Use 'Test Connection' to verify the configuration",
        ],
      });
    } catch (error) {
      logger.error("Error saving AWS role config", { error });
      res.status(500).json({ error: "Failed to save AWS role configuration" });
    }
  }
);

/**
 * POST /api/settings/integrations/aws/role/test
 * Test the AWS role configuration by attempting to assume the role
 */
router.post("/integrations/aws/role/test", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const roleConfig = await getAwsRoleConfig(org.id);

    if (!roleConfig || !roleConfig.roleArn) {
      res.status(400).json({ error: "AWS role not configured" });
      return;
    }

    const { STSClient, AssumeRoleCommand } = await import("@aws-sdk/client-sts");

    // Use the default credentials (from the ECS task role or environment)
    const stsClient = new STSClient({ region: roleConfig.region || "us-east-1" });

    try {
      const assumeRoleResult = await stsClient.send(
        new AssumeRoleCommand({
          RoleArn: roleConfig.roleArn,
          ExternalId: roleConfig.externalId,
          RoleSessionName: `workermill-test-${org.id.substring(0, 8)}`,
          DurationSeconds: 900, // 15 minutes (minimum)
        })
      );

      if (assumeRoleResult.Credentials) {
        res.json({
          success: true,
          message: "Successfully assumed customer role",
          assumedRole: {
            arn: assumeRoleResult.AssumedRoleUser?.Arn,
            assumedAt: new Date().toISOString(),
            expiresAt: assumeRoleResult.Credentials.Expiration?.toISOString(),
          },
        });
      } else {
        res.status(400).json({
          error: "Role assumption returned no credentials",
        });
      }
    } catch (assumeError) {
      const errorMessage = assumeError instanceof Error ? assumeError.message : String(assumeError);

      // Provide helpful error messages based on common issues
      let hint = "";
      if (errorMessage.includes("AccessDenied")) {
        hint = "Check that the role's trust policy includes WorkerMill's worker role and the correct external ID";
      } else if (errorMessage.includes("MalformedPolicyDocument")) {
        hint = "The role's trust policy may have syntax errors";
      } else if (errorMessage.includes("NoSuchEntity") || errorMessage.includes("not found")) {
        hint = "The role does not exist. Verify the role ARN and that the role is created in your AWS account";
      }

      res.status(400).json({
        error: `Failed to assume role: ${errorMessage}`,
        hint: hint || "Check your role's trust policy and permissions",
        roleArn: roleConfig.roleArn,
        externalId: roleConfig.externalId,
      });
    }
  } catch (error) {
    logger.error("Error testing AWS role assumption", { error });
    const message = error instanceof Error ? error.message : "Role test failed";
    res.status(500).json({ error: message });
  }
});

/**
 * PUT /api/settings/integrations/gcp
 * Save GCP credentials to Secrets Manager (org-specific)
 */
router.put(
  "/integrations/gcp",
  requireAdmin,
  body("projectId").isString().notEmpty().withMessage("projectId is required"),
  body("serviceAccountJson").isString().notEmpty().withMessage("serviceAccountJson is required"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const { projectId, serviceAccountJson } = req.body;
      const org = req.organization!;
      const secretPrefix = `workermill/${config.environment}`;

      // Validate JSON format
      try {
        JSON.parse(serviceAccountJson);
      } catch {
        res.status(400).json({ error: "Invalid service account JSON format" });
        return;
      }

      const gcpCredentials = JSON.stringify({
        project_id: projectId,
        service_account: serviceAccountJson,
      });

      await saveOrgSecret(
        org.id,
        "gcp-credentials",
        gcpCredentials,
        secretPrefix,
        `GCP credentials for org ${org.id}`
      );

      logger.info("GCP credentials updated", { orgId: org.id });

      res.json({ success: true, message: "GCP credentials saved successfully" });
    } catch (error) {
      logger.error("Error saving GCP credentials", { error });
      res.status(500).json({ error: "Failed to save GCP credentials" });
    }
  }
);

/**
 * PUT /api/settings/integrations/azure
 * Save Azure credentials to Secrets Manager (org-specific)
 */
router.put(
  "/integrations/azure",
  requireAdmin,
  body("clientId").isString().notEmpty().withMessage("clientId is required"),
  body("clientSecret").isString().notEmpty().withMessage("clientSecret is required"),
  body("tenantId").isString().notEmpty().withMessage("tenantId is required"),
  body("subscriptionId").isString().notEmpty().withMessage("subscriptionId is required"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const { clientId, clientSecret, tenantId, subscriptionId } = req.body;
      const org = req.organization!;
      const secretPrefix = `workermill/${config.environment}`;

      const azureCredentials = JSON.stringify({
        client_id: clientId,
        client_secret: clientSecret,
        tenant_id: tenantId,
        subscription_id: subscriptionId,
      });

      await saveOrgSecret(
        org.id,
        "azure-credentials",
        azureCredentials,
        secretPrefix,
        `Azure credentials for org ${org.id}`
      );

      logger.info("Azure credentials updated", { orgId: org.id });

      res.json({ success: true, message: "Azure credentials saved successfully" });
    } catch (error) {
      logger.error("Error saving Azure credentials", { error });
      res.status(500).json({ error: "Failed to save Azure credentials" });
    }
  }
);

/**
 * POST /api/settings/integrations/azure/test
 * Test Azure credentials by getting an access token
 */
router.post("/integrations/azure/test", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const secretPrefix = `workermill/${config.environment}`;

    const azureSecretString = await getOrgSecret(org.id, "azure-credentials", secretPrefix);

    if (!azureSecretString) {
      res.status(400).json({ error: "Azure credentials not configured" });
      return;
    }

    const azureCreds = JSON.parse(azureSecretString);
    const { client_id, client_secret, tenant_id } = azureCreds;

    if (!client_id || !client_secret || !tenant_id) {
      res.status(400).json({ error: "Incomplete Azure credentials" });
      return;
    }

    // Get access token from Azure AD
    const tokenUrl = `https://login.microsoftonline.com/${tenant_id}/oauth2/v2.0/token`;
    const response = await fetch(tokenUrl, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id,
        client_secret,
        scope: "https://management.azure.com/.default",
        grant_type: "client_credentials",
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      logger.warn("Azure authentication failed", { status: response.status, error: errorText });
      res.status(400).json({ error: `Azure authentication failed: ${response.status}` });
      return;
    }

    res.json({
      success: true,
      message: "Azure connection successful",
      tenantId: tenant_id,
    });
  } catch (error) {
    logger.error("Error testing Azure credentials", { error });
    const message = error instanceof Error ? error.message : "Azure connection failed";
    res.status(400).json({ error: message });
  }
});

// =============================================================================
// Dynamic Model Discovery
// =============================================================================

interface DiscoveredModel {
  id: string;
  displayName: string;
  provider: string;
  tier?: string;
  contextWindow?: number;
  source: "curated" | "discovered";
}

// Cache for discovered models (60 second TTL)
const modelCache = new Map<string, { models: DiscoveredModel[]; timestamp: number }>();
const MODEL_CACHE_TTL_MS = 60000;

// Curated model lists for providers without dynamic discovery
const CURATED_MODELS: Record<string, DiscoveredModel[]> = {
  anthropic: [
    { id: "claude-opus-4-6", displayName: "Claude Opus 4.6", provider: "anthropic", tier: "premium", contextWindow: 200000, source: "curated" },
    { id: "claude-opus-4-5-20251101", displayName: "Claude Opus 4.5", provider: "anthropic", tier: "premium", contextWindow: 200000, source: "curated" },
    { id: "claude-sonnet-5-20260203", displayName: "Claude Sonnet 5", provider: "anthropic", tier: "standard", contextWindow: 1000000, source: "curated" },
    { id: "claude-sonnet-4-5-20250929", displayName: "Claude Sonnet 4.5", provider: "anthropic", tier: "standard", contextWindow: 200000, source: "curated" },
    { id: "claude-haiku-4-5-20251001", displayName: "Claude Haiku 4.5", provider: "anthropic", tier: "economy", contextWindow: 200000, source: "curated" },
    // Legacy models for backwards compatibility
    { id: "claude-3-5-haiku-20241022", displayName: "Claude 3.5 Haiku (Legacy)", provider: "anthropic", tier: "economy", contextWindow: 200000, source: "curated" },
    { id: "claude-3-5-sonnet-20241022", displayName: "Claude 3.5 Sonnet (Legacy)", provider: "anthropic", tier: "standard", contextWindow: 200000, source: "curated" },
    { id: "claude-3-opus-20240229", displayName: "Claude 3 Opus (Legacy)", provider: "anthropic", tier: "premium", contextWindow: 200000, source: "curated" },
    // Deprecated model IDs (mapped to current equivalents for backwards compatibility)
    { id: "claude-sonnet-4-20250514", displayName: "Claude Sonnet 4 (Deprecated)", provider: "anthropic", tier: "standard", contextWindow: 200000, source: "curated" },
    { id: "claude-sonnet-4-5-20250514", displayName: "Claude Sonnet 4.5 (Deprecated)", provider: "anthropic", tier: "standard", contextWindow: 200000, source: "curated" },
    { id: "claude-haiku-4-5-20250514", displayName: "Claude Haiku 4.5 (Deprecated)", provider: "anthropic", tier: "economy", contextWindow: 200000, source: "curated" },
  ],
  openai: [
    { id: "gpt-5.1-codex", displayName: "GPT-5.1 Codex", provider: "openai", tier: "premium", contextWindow: 128000, source: "curated" },
    { id: "gpt-4o", displayName: "GPT-4o", provider: "openai", tier: "standard", contextWindow: 128000, source: "curated" },
    { id: "gpt-4o-mini", displayName: "GPT-4o Mini", provider: "openai", tier: "economy", contextWindow: 128000, source: "curated" },
    { id: "o1", displayName: "O1", provider: "openai", tier: "premium", contextWindow: 128000, source: "curated" },
    { id: "o1-mini", displayName: "O1 Mini", provider: "openai", tier: "standard", contextWindow: 128000, source: "curated" },
  ],
  google: [
    { id: "gemini-2.5-pro", displayName: "Gemini 2.5 Pro", provider: "google", tier: "premium", contextWindow: 1000000, source: "curated" },
    { id: "gemini-2.5-flash", displayName: "Gemini 2.5 Flash", provider: "google", tier: "standard", contextWindow: 1000000, source: "curated" },
    { id: "gemini-2.0-flash", displayName: "Gemini 2.0 Flash", provider: "google", tier: "economy", contextWindow: 1000000, source: "curated" },
    { id: "gemini-3-pro-preview", displayName: "Gemini 3 Pro Preview (Unstable)", provider: "google", tier: "experimental", contextWindow: 1000000, source: "curated" },
    { id: "gemini-1.5-pro", displayName: "Gemini 1.5 Pro (Legacy)", provider: "google", tier: "standard", contextWindow: 1000000, source: "curated" },
    { id: "gemini-1.5-flash", displayName: "Gemini 1.5 Flash (Legacy)", provider: "google", tier: "economy", contextWindow: 1000000, source: "curated" },
  ],
};

/**
 * Fetch available models from Ollama server
 */
async function discoverOllamaModels(ollamaHost: string): Promise<DiscoveredModel[]> {
  try {
    const response = await fetch(`${ollamaHost}/api/tags`, {
      method: "GET",
      signal: AbortSignal.timeout(5000), // 5 second timeout
    });

    if (!response.ok) {
      logger.warn("Ollama models endpoint returned error", { status: response.status });
      return [];
    }

    const data = await response.json() as { models?: Array<{ name: string; details?: { parameter_size?: string } }> };

    if (!data.models || !Array.isArray(data.models)) {
      return [];
    }

    return data.models.map((model) => ({
      id: model.name,
      displayName: formatOllamaModelName(model.name, model.details?.parameter_size),
      provider: "ollama",
      source: "discovered" as const,
    }));
  } catch (error) {
    logger.warn("Failed to discover Ollama models", {
      error: error instanceof Error ? error.message : String(error),
      host: ollamaHost
    });
    return [];
  }
}

/**
 * Format Ollama model name for display
 * e.g., "qwen2.5-coder:32b" -> "Qwen 2.5 Coder (32B)"
 */
function formatOllamaModelName(modelId: string, paramSize?: string): string {
  const [baseName, tag] = modelId.split(":");

  // Capitalize and clean up the base name
  const formatted = baseName
    .replace(/-/g, " ")
    .replace(/(\d+)\.(\d+)/g, "$1.$2") // Keep version numbers
    .split(" ")
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");

  // Add parameter size if available
  const size = paramSize || (tag ? tag.toUpperCase() : "");
  return size ? `${formatted} (${size})` : formatted;
}

/**
 * Get all available models for an organization
 */
async function getAvailableModels(org: { id: string; ollamaBaseUrl?: string | null }): Promise<{
  models: DiscoveredModel[];
  ollamaStatus: "connected" | "disconnected" | "not_configured";
}> {
  const cacheKey = `models-${org.id}`;
  const cached = modelCache.get(cacheKey);

  if (cached && Date.now() - cached.timestamp < MODEL_CACHE_TTL_MS) {
    // Determine ollama status from cached models
    const hasOllamaModels = cached.models.some(m => m.provider === "ollama" && m.source === "discovered");
    return {
      models: cached.models,
      ollamaStatus: hasOllamaModels ? "connected" : (org.ollamaBaseUrl ? "disconnected" : "not_configured"),
    };
  }

  // Start with curated models
  const models: DiscoveredModel[] = [
    ...CURATED_MODELS.anthropic,
    ...CURATED_MODELS.openai,
    ...CURATED_MODELS.google,
  ];

  // Discover Ollama models if configured
  let ollamaStatus: "connected" | "disconnected" | "not_configured" = "not_configured";
  const ollamaHost = org.ollamaBaseUrl || process.env.OLLAMA_HOST;

  if (ollamaHost) {
    const ollamaModels = await discoverOllamaModels(ollamaHost);
    if (ollamaModels.length > 0) {
      models.push(...ollamaModels);
      ollamaStatus = "connected";
    } else {
      ollamaStatus = "disconnected";
    }
  }

  // Cache the results
  modelCache.set(cacheKey, { models, timestamp: Date.now() });

  return { models, ollamaStatus };
}

/**
 * Check if a model ID is valid (either in available models or Ollama format)
 */
function isValidModelId(modelId: string, availableModels: DiscoveredModel[]): boolean {
  // Check if in available models list
  if (availableModels.some(m => m.id === modelId)) {
    return true;
  }

  // Accept any Ollama format model (name:tag) as fallback
  // This ensures models work even if Ollama server is temporarily unreachable
  if (modelId.includes(":")) {
    return true;
  }

  return false;
}

/**
 * Infer the provider from a model ID
 * Returns the provider name or null if unknown
 */
function inferProviderFromModelId(modelId: string): string | null {
  if (modelId.startsWith("claude-") || modelId.includes("claude")) {
    return "anthropic";
  }
  if (modelId.startsWith("gpt-") || modelId.startsWith("o1") || modelId.includes("codex")) {
    return "openai";
  }
  if (modelId.startsWith("gemini-")) {
    return "google";
  }
  if (modelId.includes(":")) {
    return "ollama";
  }
  return null;
}

/**
 * GET /api/settings/models
 * Get all available models from all providers (with dynamic Ollama discovery)
 */
router.get("/models", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const result = await getAvailableModels(org);

    res.json({
      models: result.models,
      ollamaStatus: result.ollamaStatus,
      ollamaHost: org.ollamaBaseUrl || process.env.OLLAMA_HOST || null,
    });
  } catch (error) {
    logger.error("Error fetching available models", { error });
    res.status(500).json({ error: "Failed to fetch available models" });
  }
});

/**
 * POST /api/settings/models/refresh
 * Force refresh the model cache (clears cache and re-discovers)
 */
router.post("/models/refresh", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const cacheKey = `models-${org.id}`;

    // Clear cache
    modelCache.delete(cacheKey);

    // Re-discover
    const result = await getAvailableModels(org);

    logger.info("Model cache refreshed", { orgId: org.id, modelCount: result.models.length });

    res.json({
      models: result.models,
      ollamaStatus: result.ollamaStatus,
      ollamaHost: org.ollamaBaseUrl || process.env.OLLAMA_HOST || null,
      refreshed: true,
    });
  } catch (error) {
    logger.error("Error refreshing models", { error });
    res.status(500).json({ error: "Failed to refresh models" });
  }
});

// =============================================================================
// Provider Management Endpoints
// =============================================================================

/**
 * GET /api/settings/providers
 * List all available providers with their configuration status
 */
router.get("/providers", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const providers = listProviders();

    // Check credentials status for each provider
    const providerStatuses = await Promise.all(
      providers.map(async (provider) => {
        const hasCredentials = await hasProviderCredentials(
          org.id,
          provider.id as ProviderId
        );

        return {
          id: provider.id,
          name: provider.name,
          defaultModel: provider.defaultModel,
          requiresApiKey: provider.requiresApiKey,
          configured: hasCredentials,
          models: provider.pricingEngine.getModels().map((m) => ({
            id: m.id,
            displayName: m.displayName,
            tier: m.tier,
            contextWindow: m.contextWindow,
          })),
        };
      })
    );

    res.json({
      providers: providerStatuses,
      primaryProvider: org.primaryProvider || "anthropic",
    });
  } catch (error) {
    logger.error("Error listing providers", { error });
    res.status(500).json({ error: "Failed to list providers" });
  }
});

/**
 * POST /api/settings/providers/:providerId/test
 * Test provider credentials by making a simple API call
 */
router.post("/providers/:providerId/test", async (req: Request, res: Response) => {
  try {
    const providerId = req.params.providerId as string;
    const org = req.organization!;

    if (!isValidProviderId(providerId)) {
      res.status(400).json({ error: `Invalid provider ID: ${providerId}` });
      return;
    }

    if (!hasProvider(providerId)) {
      res.status(404).json({ error: `Provider not found: ${providerId}` });
      return;
    }

    const provider = getProvider(providerId);

    // For Ollama, just check if the host is reachable
    if (providerId === "ollama") {
      const ollamaHost = process.env.OLLAMA_HOST || "http://localhost:11434";
      try {
        const response = await fetch(`${ollamaHost}/api/tags`, {
          method: "GET",
        });
        if (response.ok) {
          res.json({
            success: true,
            message: "Ollama connection successful",
            host: ollamaHost,
          });
        } else {
          res.status(400).json({ error: `Ollama not reachable at ${ollamaHost}` });
        }
      } catch {
        res.status(400).json({ error: `Ollama not reachable at ${ollamaHost}` });
      }
      return;
    }

    // SECURITY: Only test org-specific credentials - NO platform fallback for multi-tenancy isolation
    const secretPrefix = `workermill/${config.environment}`;
    const orgSecretPath = `${secretPrefix}/orgs/${org.id}/providers/${providerId}`;

    let apiKey: string | null = null;

    // Only check org-specific credentials
    try {
      const orgSecret = await secretsClient.send(
        new GetSecretValueCommand({ SecretId: orgSecretPath })
      );
      apiKey = orgSecret.SecretString || null;
    } catch {
      // Org-specific credentials not found - do NOT fall back to platform credentials
    }

    if (!apiKey) {
      res.status(400).json({
        error: `${provider.name} API key not configured for your organization`,
        configured: false,
        hint: "Please add your API key in Settings > AI Providers",
      });
      return;
    }

    // Test the API key based on provider
    let testResult: { success: boolean; message: string; details?: unknown };

    switch (providerId) {
      case "anthropic":
        testResult = await testAnthropicApiKey(apiKey);
        break;
      case "openai":
        testResult = await testOpenAIApiKey(apiKey);
        break;
      case "google":
        testResult = await testGoogleApiKey(apiKey);
        break;
      default:
        testResult = { success: false, message: `Testing not implemented for ${providerId}` };
    }

    if (testResult.success) {
      res.json(testResult);
    } else {
      res.status(400).json(testResult);
    }
  } catch (error) {
    logger.error("Error testing provider credentials", { error });
    res.status(500).json({ error: "Failed to test provider credentials" });
  }
});

/**
 * PUT /api/settings/providers/:providerId/credentials
 * Save provider credentials to Secrets Manager
 */
router.put(
  "/providers/:providerId/credentials",
  requireAdmin,
  async (req: Request, res: Response) => {
    try {
      const providerId = req.params.providerId as string;
      const { apiKey } = req.body;
      const org = req.organization!;

      if (!isValidProviderId(providerId)) {
        res.status(400).json({ error: `Invalid provider ID: ${providerId}` });
        return;
      }

      if (!hasProvider(providerId)) {
        res.status(404).json({ error: `Provider not found: ${providerId}` });
        return;
      }

      const provider = getProvider(providerId);

      // Ollama doesn't need credentials
      if (providerId === "ollama") {
        res.json({
          success: true,
          message: "Ollama does not require API credentials",
        });
        return;
      }

      if (!apiKey) {
        res.status(400).json({ error: "Missing required field: apiKey" });
        return;
      }

      // Save to org-specific secret path
      const secretPrefix = `workermill/${config.environment}`;
      const secretPath = `${secretPrefix}/orgs/${org.id}/providers/${providerId}`;

      try {
        // Try to update existing secret
        await secretsClient.send(
          new PutSecretValueCommand({
            SecretId: secretPath,
            SecretString: apiKey,
          })
        );
      } catch (error) {
        // If secret doesn't exist, create it
        if (error instanceof ResourceNotFoundException) {
          await secretsClient.send(
            new CreateSecretCommand({
              Name: secretPath,
              SecretString: apiKey,
              Description: `${provider.name} API key for org ${org.id}`,
            })
          );
        } else {
          throw error;
        }
      }

      // Clear the credentials cache for this org/provider
      clearProviderCredentialsCache(org.id, providerId as ProviderId);

      logger.info("Provider credentials updated", {
        orgId: org.id,
        providerId,
      });

      res.json({
        success: true,
        message: `${provider.name} credentials saved successfully`,
      });
    } catch (error) {
      logger.error("Error saving provider credentials", { error });
      res.status(500).json({ error: "Failed to save provider credentials" });
    }
  }
);

/**
 * DELETE /api/settings/providers/:providerId/credentials
 * Remove provider credentials from Secrets Manager
 */
router.delete(
  "/providers/:providerId/credentials",
  requireAdmin,
  async (req: Request, res: Response) => {
    try {
      const providerId = req.params.providerId as string;
      const org = req.organization!;

      if (!isValidProviderId(providerId)) {
        res.status(400).json({ error: `Invalid provider ID: ${providerId}` });
        return;
      }

      // Don't allow deleting anthropic credentials (platform default)
      if (providerId === "anthropic") {
        res.status(400).json({
          error: "Cannot delete Anthropic credentials. This is the platform default provider.",
        });
        return;
      }

      const secretPrefix = `workermill/${config.environment}`;
      const secretPath = `${secretPrefix}/orgs/${org.id}/providers/${providerId}`;

      // We don't actually delete the secret, just clear it (to keep the secret structure)
      // This allows the secret to be re-used without needing create permissions
      try {
        await secretsClient.send(
          new PutSecretValueCommand({
            SecretId: secretPath,
            SecretString: "", // Empty string to "delete" credentials
          })
        );
      } catch (error) {
        if (!(error instanceof ResourceNotFoundException)) {
          throw error;
        }
        // Secret doesn't exist, that's fine
      }

      // Clear the credentials cache
      clearProviderCredentialsCache(org.id, providerId as ProviderId);

      logger.info("Provider credentials removed", {
        orgId: org.id,
        providerId,
      });

      res.json({
        success: true,
        message: `${providerId} credentials removed successfully`,
      });
    } catch (error) {
      logger.error("Error removing provider credentials", { error });
      res.status(500).json({ error: "Failed to remove provider credentials" });
    }
  }
);

// =============================================================================
// OnCallShift Integration
// =============================================================================

/**
 * PUT /api/settings/integrations/oncallshift
 * Save OnCallShift API key to Secrets Manager (org-specific)
 */
router.put(
  "/integrations/oncallshift",
  requireAdmin,
  body("apiKey").notEmpty().isString().withMessage("apiKey is required"),
  body("baseUrl").optional().isString().withMessage("baseUrl must be a string"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const { apiKey, baseUrl } = req.body;
      const org = req.organization!;
      const secretPrefix = `workermill/${config.environment}`;

      // Store API key and optional base URL together
      const oncallshiftCredentials = JSON.stringify({
        api_key: apiKey,
        base_url: baseUrl || "https://api.oncallshift.com",
      });

      await saveOrgSecret(
        org.id,
        "oncallshift-credentials",
        oncallshiftCredentials,
        secretPrefix,
        `OnCallShift credentials for org ${org.id}`
      );

      logger.info("OnCallShift credentials saved", { orgId: org.id });
      res.json({ success: true, message: "OnCallShift credentials saved successfully" });
    } catch (error) {
      logger.error("Error saving OnCallShift credentials", { error });
      res.status(500).json({ error: "Failed to save OnCallShift credentials" });
    }
  }
);

/**
 * POST /api/settings/integrations/oncallshift/test
 * Test OnCallShift connection by listing services
 */
router.post("/integrations/oncallshift/test", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const secretPrefix = `workermill/${config.environment}`;

    // Get OnCallShift credentials (org-specific with fallback)
    const oncallshiftSecret = await getOrgSecret(org.id, "oncallshift-credentials", secretPrefix);

    if (!oncallshiftSecret) {
      res.status(400).json({ error: "OnCallShift API key not configured" });
      return;
    }

    let apiKey: string;
    let baseUrl: string;
    try {
      const creds = JSON.parse(oncallshiftSecret);
      apiKey = creds.api_key;
      baseUrl = creds.base_url || "https://api.oncallshift.com";
    } catch {
      res.status(400).json({ error: "Invalid OnCallShift credentials format" });
      return;
    }

    // Test connection by listing services
    const response = await fetch(`${baseUrl}/api/v1/services`, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      logger.warn("OnCallShift connection test failed", { status: response.status, error: errorText });
      res.status(400).json({ error: `OnCallShift connection failed: ${response.status} - ${errorText}` });
      return;
    }

    const data = await response.json() as { services?: unknown[]; data?: unknown[] };
    const serviceCount = data.services?.length || data.data?.length || 0;

    res.json({
      success: true,
      message: "OnCallShift connection successful",
      serviceCount,
    });
  } catch (error) {
    logger.error("Error testing OnCallShift connection", { error });
    res.status(500).json({ error: `Failed to test OnCallShift connection: ${error instanceof Error ? error.message : String(error)}` });
  }
});

// =============================================================================
// Provider Test Helper Functions
// =============================================================================

/**
 * Test Anthropic API key by listing models
 */
async function testAnthropicApiKey(
  apiKey: string
): Promise<{ success: boolean; message: string; details?: unknown }> {
  try {
    const response = await fetch("https://api.anthropic.com/v1/models", {
      method: "GET",
      headers: {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
    });

    if (response.ok) {
      return { success: true, message: "Anthropic API key is valid" };
    }

    const errorData = (await response.json()) as { error?: { message?: string } };
    return {
      success: false,
      message: `Anthropic API error: ${errorData.error?.message || response.statusText}`,
    };
  } catch (error) {
    return {
      success: false,
      message: `Failed to connect to Anthropic API: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}

/**
 * Test OpenAI API key by listing models
 */
async function testOpenAIApiKey(
  apiKey: string
): Promise<{ success: boolean; message: string; details?: unknown }> {
  try {
    const response = await fetch("https://api.openai.com/v1/models", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${apiKey}`,
      },
    });

    if (response.ok) {
      return { success: true, message: "OpenAI API key is valid" };
    }

    const errorData = (await response.json()) as { error?: { message?: string } };
    return {
      success: false,
      message: `OpenAI API error: ${errorData.error?.message || response.statusText}`,
    };
  } catch (error) {
    return {
      success: false,
      message: `Failed to connect to OpenAI API: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}

/**
 * Test Google API key by listing models
 */
async function testGoogleApiKey(
  apiKey: string
): Promise<{ success: boolean; message: string; details?: unknown }> {
  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`,
      {
        method: "GET",
      }
    );

    if (response.ok) {
      return { success: true, message: "Google API key is valid" };
    }

    const errorData = (await response.json()) as { error?: { message?: string } };
    return {
      success: false,
      message: `Google API error: ${errorData.error?.message || response.statusText}`,
    };
  } catch (error) {
    return {
      success: false,
      message: `Failed to connect to Google API: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}

// ============================================================================
// WEBHOOK ENDPOINT MANAGEMENT (Multi-Tenant Isolation)
// ============================================================================

/**
 * GET /api/settings/webhooks
 * Get all webhook endpoints for the organization with URLs
 */
router.get("/webhooks", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const baseUrl = config.apiBaseUrl || `${req.protocol}://${req.get("host")}`;

    // Get existing endpoints
    const endpoints = await getWebhookEndpointsWithUrls(org.id, baseUrl);

    // Define all supported integration types
    const allIntegrationTypes: IntegrationType[] = [
      "jira",
      "github",
      "github-issues",
      "gitlab",
      "bitbucket",
      "linear",
    ];

    // Create a map of existing endpoints
    const existingMap = new Map(endpoints.map((e) => [e.integrationType, e]));

    // Build response with all integration types
    const result = allIntegrationTypes.map((type) => {
      const existing = existingMap.get(type);
      const slug = org.slug || "";

      return {
        integrationType: type,
        webhookUrl: slug ? `${baseUrl}/api/webhooks/${slug}/${type}` : null,
        isConfigured: !!existing,
        isActive: existing?.isActive ?? false,
        lastReceivedAt: existing?.lastReceivedAt ?? null,
        hasSecret: existing?.hasSecret ?? false,
      };
    });

    res.json({
      orgSlug: org.slug,
      endpoints: result,
      legacyWarning: org.slug
        ? null
        : "Organization slug not set. Please update your organization to enable URL-based webhooks.",
    });
  } catch (error) {
    logger.error("Error fetching webhook endpoints", { error });
    res.status(500).json({ error: "Failed to fetch webhook endpoints" });
  }
});

/**
 * POST /api/settings/webhooks/:integrationType
 * Create or regenerate a webhook endpoint for an integration type
 */
router.post(
  "/webhooks/:integrationType",
  param("integrationType")
    .isIn(["jira", "github", "github-issues", "gitlab", "bitbucket", "linear"])
    .withMessage("Invalid integration type"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const org = req.organization!;
      const { integrationType } = req.params as { integrationType: IntegrationType };

      if (!org.slug) {
        res.status(400).json({
          error: "Organization slug not set. Please set a slug before configuring webhooks.",
        });
        return;
      }

      // Create or update the endpoint with a new secret
      const newSecret = generateWebhookSecret();
      const endpoint = await ensureWebhookEndpoint(org.id, integrationType, newSecret);

      const baseUrl = config.apiBaseUrl || `${req.protocol}://${req.get("host")}`;
      const webhookUrl = endpoint.getWebhookUrl(baseUrl, org.slug);

      logger.info("Created/updated webhook endpoint", {
        orgId: org.id,
        integrationType,
        endpointId: endpoint.id,
      });

      res.status(201).json({
        integrationType,
        webhookUrl,
        webhookSecret: newSecret, // Only returned on creation/regeneration
        isActive: endpoint.isActive,
        message: "Webhook endpoint configured. Use the secret to verify webhook signatures.",
      });
    } catch (error) {
      logger.error("Error creating webhook endpoint", { error });
      res.status(500).json({ error: "Failed to create webhook endpoint" });
    }
  }
);

/**
 * DELETE /api/settings/webhooks/:integrationType
 * Deactivate a webhook endpoint (soft delete)
 */
router.delete(
  "/webhooks/:integrationType",
  param("integrationType")
    .isIn(["jira", "github", "github-issues", "gitlab", "bitbucket", "linear"])
    .withMessage("Invalid integration type"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const org = req.organization!;
      const { integrationType } = req.params as { integrationType: IntegrationType };

      const endpointRepo = AppDataSource.getRepository(WebhookEndpoint);
      const endpoint = await endpointRepo.findOne({
        where: { orgId: org.id, integrationType },
      });

      if (!endpoint) {
        res.status(404).json({ error: "Webhook endpoint not found" });
        return;
      }

      // Soft delete - just deactivate
      endpoint.isActive = false;
      await endpointRepo.save(endpoint);

      logger.info("Deactivated webhook endpoint", {
        orgId: org.id,
        integrationType,
        endpointId: endpoint.id,
      });

      res.json({
        message: "Webhook endpoint deactivated",
        integrationType,
      });
    } catch (error) {
      logger.error("Error deactivating webhook endpoint", { error });
      res.status(500).json({ error: "Failed to deactivate webhook endpoint" });
    }
  }
);

/**
 * PATCH /api/settings/webhooks/:integrationType/activate
 * Reactivate a previously deactivated webhook endpoint
 */
router.patch(
  "/webhooks/:integrationType/activate",
  param("integrationType")
    .isIn(["jira", "github", "github-issues", "gitlab", "bitbucket", "linear"])
    .withMessage("Invalid integration type"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const org = req.organization!;
      const { integrationType } = req.params as { integrationType: IntegrationType };

      const endpointRepo = AppDataSource.getRepository(WebhookEndpoint);
      const endpoint = await endpointRepo.findOne({
        where: { orgId: org.id, integrationType },
      });

      if (!endpoint) {
        res.status(404).json({ error: "Webhook endpoint not found" });
        return;
      }

      endpoint.isActive = true;
      await endpointRepo.save(endpoint);

      const baseUrl = config.apiBaseUrl || `${req.protocol}://${req.get("host")}`;
      const webhookUrl = org.slug
        ? endpoint.getWebhookUrl(baseUrl, org.slug)
        : null;

      logger.info("Reactivated webhook endpoint", {
        orgId: org.id,
        integrationType,
        endpointId: endpoint.id,
      });

      res.json({
        message: "Webhook endpoint activated",
        integrationType,
        webhookUrl,
        isActive: true,
      });
    } catch (error) {
      logger.error("Error activating webhook endpoint", { error });
      res.status(500).json({ error: "Failed to activate webhook endpoint" });
    }
  }
);

/**
 * PATCH /api/settings/slug
 * Update the organization's slug (URL-safe identifier)
 */
router.patch(
  "/slug",
  body("slug")
    .isString()
    .isLength({ min: 3, max: 100 })
    .matches(/^[a-z0-9][a-z0-9-]*[a-z0-9]$/)
    .withMessage("Slug must be 3-100 characters, lowercase alphanumeric with hyphens, not starting/ending with hyphen"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const org = req.organization!;
      const { slug } = req.body;

      const orgRepo = AppDataSource.getRepository(Organization);

      // Check for conflicts
      const existing = await orgRepo.findOne({ where: { slug } });
      if (existing && existing.id !== org.id) {
        res.status(409).json({ error: "Slug already in use by another organization" });
        return;
      }

      const oldSlug = org.slug;
      org.slug = slug;
      await orgRepo.save(org);

      logger.info("Updated organization slug", {
        orgId: org.id,
        oldSlug,
        newSlug: slug,
      });

      res.json({
        message: "Organization slug updated",
        slug,
        warning: oldSlug
          ? "Webhook URLs have changed. Update your integrations with the new URLs."
          : null,
      });
    } catch (error) {
      logger.error("Error updating organization slug", { error });
      res.status(500).json({ error: "Failed to update organization slug" });
    }
  }
);

// =============================================================================
// Legacy Webhook Monitoring
// =============================================================================

import { getLegacyWebhookStats } from "../services/legacy-webhook-alert.js";

/**
 * GET /api/settings/webhooks/legacy-usage
 * Get legacy (deprecated) webhook endpoint usage stats for this org
 */
router.get("/webhooks/legacy-usage", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const stats = getLegacyWebhookStats(org.id);

    // Also get audit log count for more accurate historical data
    const auditRepo = AppDataSource.getRepository(AuditLog);
    const legacyUsageCount = await auditRepo.count({
      where: {
        organizationId: org.id,
        action: "webhook_legacy_used" as AuditAction,
      },
    });

    res.json({
      currentSession: stats,
      totalHistorical: legacyUsageCount,
      message: Object.values(stats).some((v) => v > 0)
        ? "Legacy webhook endpoints are being used. Please migrate to URL-based endpoints for proper multi-tenant isolation."
        : "No legacy webhook usage detected.",
    });
  } catch (error) {
    logger.error("Error fetching legacy webhook stats", { error });
    res.status(500).json({ error: "Failed to fetch legacy webhook stats" });
  }
});

// =============================================================================
// Persona Management Endpoints
// =============================================================================

import {
  getValidPersonasForOrg,
  inferPersonaFromJiraIssue,
  SYSTEM_PERSONAS,
  PERSONA_KEYWORDS,
} from "../services/persona-inference.js";

/**
 * GET /api/settings/personas
 * List all valid personas for this organization (system + custom)
 */
router.get("/personas", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const personas = await getValidPersonasForOrg(org.id);

    res.json({
      personas,
      inferenceRules: org.personaInferenceRules || {},
    });
  } catch (error) {
    logger.error("Error getting personas", { error });
    res.status(500).json({ error: "Failed to get personas" });
  }
});

/**
 * GET /api/settings/persona-inference-rules
 * Get org-specific persona inference rules
 */
router.get("/persona-inference-rules", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;

    res.json({
      // Org-specific rules
      rules: org.personaInferenceRules || {},
      // System defaults for reference
      defaults: {
        labelMappings: {
          backend: "backend_developer",
          frontend: "frontend_developer",
          api: "api_engineer",
          devops: "devops_engineer",
          infra: "devops_engineer",
          security: "security_engineer",
          qa: "qa_engineer",
          test: "qa_engineer",
          docs: "tech_writer",
          documentation: "tech_writer",
        },
        keywordPatterns: PERSONA_KEYWORDS,
        availableSystemPersonas: SYSTEM_PERSONAS,
      },
    });
  } catch (error) {
    logger.error("Error getting persona inference rules", { error });
    res.status(500).json({ error: "Failed to get persona inference rules" });
  }
});

/**
 * PUT /api/settings/persona-inference-rules
 * Update org-specific persona inference rules
 */
router.put(
  "/persona-inference-rules",
  requireAdmin,
  async (req: Request, res: Response) => {
    try {
      const org = req.organization!;
      const orgRepo = AppDataSource.getRepository(Organization);

      const { labelMappings, keywordPatterns, defaultPersona } = req.body;

      // Validate structure
      const rules: Record<string, unknown> = {};

      if (labelMappings !== undefined) {
        if (typeof labelMappings !== "object" || labelMappings === null) {
          res.status(400).json({ error: "labelMappings must be an object" });
          return;
        }
        // Validate all values are strings (persona slugs)
        for (const [label, persona] of Object.entries(labelMappings)) {
          if (typeof persona !== "string") {
            res.status(400).json({
              error: `labelMappings["${label}"] must be a string (persona slug)`,
            });
            return;
          }
        }
        rules.labelMappings = labelMappings;
      }

      if (keywordPatterns !== undefined) {
        if (typeof keywordPatterns !== "object" || keywordPatterns === null) {
          res.status(400).json({ error: "keywordPatterns must be an object" });
          return;
        }
        // Validate all values are valid regex strings
        for (const [persona, pattern] of Object.entries(keywordPatterns)) {
          if (typeof pattern !== "string") {
            res.status(400).json({
              error: `keywordPatterns["${persona}"] must be a string (regex pattern)`,
            });
            return;
          }
          try {
            new RegExp(pattern, "i"); // Test if valid regex
          } catch {
            res.status(400).json({
              error: `keywordPatterns["${persona}"] is not a valid regex: ${pattern}`,
            });
            return;
          }
        }
        rules.keywordPatterns = keywordPatterns;
      }

      if (defaultPersona !== undefined) {
        if (typeof defaultPersona !== "string") {
          res.status(400).json({ error: "defaultPersona must be a string" });
          return;
        }
        rules.defaultPersona = defaultPersona;
      }

      // Merge with existing rules (don't replace, merge)
      org.personaInferenceRules = {
        ...org.personaInferenceRules,
        ...rules,
      };

      await orgRepo.save(org);

      logger.info("Updated persona inference rules", {
        orgId: org.id,
        rules: org.personaInferenceRules,
      });

      res.json({
        message: "Persona inference rules updated",
        rules: org.personaInferenceRules,
      });
    } catch (error) {
      logger.error("Error updating persona inference rules", { error });
      res.status(500).json({ error: "Failed to update persona inference rules" });
    }
  }
);

/**
 * DELETE /api/settings/persona-inference-rules
 * Reset org-specific persona inference rules to defaults
 */
router.delete(
  "/persona-inference-rules",
  requireAdmin,
  async (req: Request, res: Response) => {
    try {
      const org = req.organization!;
      const orgRepo = AppDataSource.getRepository(Organization);

      org.personaInferenceRules = {};
      await orgRepo.save(org);

      logger.info("Reset persona inference rules to defaults", {
        orgId: org.id,
      });

      res.json({
        message: "Persona inference rules reset to defaults",
      });
    } catch (error) {
      logger.error("Error resetting persona inference rules", { error });
      res.status(500).json({ error: "Failed to reset persona inference rules" });
    }
  }
);

/**
 * POST /api/settings/test-persona-inference
 * Test which persona would be inferred for given content
 */
router.post("/test-persona-inference", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const { summary, description, labels } = req.body;

    if (!summary && !description && !labels) {
      res.status(400).json({
        error: "At least one of summary, description, or labels is required",
      });
      return;
    }

    const inferredPersona = await inferPersonaFromJiraIssue(
      {
        summary: summary || "",
        description: description || "",
        labels: labels || [],
        fields: { labels: labels || [] },
      },
      undefined,
      org.id
    );

    res.json({
      inferredPersona,
      input: { summary, description, labels },
      orgRules: org.personaInferenceRules || {},
    });
  } catch (error) {
    logger.error("Error testing persona inference", { error });
    res.status(500).json({ error: "Failed to test persona inference" });
  }
});

// =============================================================================
// Multi-Organization Support
// =============================================================================

import {
  getUserOrganizations,
  setDefaultOrganization,
  hasOrgAccess,
} from "../services/user-organizations.js";

/**
 * GET /api/settings/organizations
 * List all organizations the current user belongs to
 */
router.get("/organizations", async (req: Request, res: Response) => {
  try {
    const user = req.user!;
    const orgs = await getUserOrganizations(user.id);

    res.json({
      organizations: orgs,
      currentOrgId: req.organization?.id,
    });
  } catch (error) {
    logger.error("Error fetching user organizations", { error });
    res.status(500).json({ error: "Failed to fetch organizations" });
  }
});

/**
 * POST /api/settings/organizations/switch
 * Switch to a different organization
 */
router.post(
  "/organizations/switch",
  body("orgId").isUUID().withMessage("orgId must be a valid UUID"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const user = req.user!;
      const { orgId } = req.body;

      // Verify user has access to this org
      const hasAccess = await hasOrgAccess(user.id, orgId);
      if (!hasAccess) {
        res.status(403).json({ error: "You do not have access to this organization" });
        return;
      }

      // Update user's default org
      await setDefaultOrganization(user.id, orgId);

      // Get the new org details
      const orgRepo = AppDataSource.getRepository(Organization);
      const newOrg = await orgRepo.findOne({ where: { id: orgId } });

      res.json({
        message: "Switched to organization successfully",
        organization: {
          id: newOrg?.id,
          name: newOrg?.name,
          slug: newOrg?.slug,
        },
      });
    } catch (error) {
      logger.error("Error switching organization", { error });
      res.status(500).json({ error: "Failed to switch organization" });
    }
  }
);

/**
 * PUT /api/settings/organizations/default
 * Set the default organization (same as switch but explicitly named)
 */
router.put(
  "/organizations/default",
  body("orgId").isUUID().withMessage("orgId must be a valid UUID"),
  validateRequest,
  async (req: Request, res: Response) => {
    try {
      const user = req.user!;
      const { orgId } = req.body;

      // Verify user has access to this org
      const hasAccess = await hasOrgAccess(user.id, orgId);
      if (!hasAccess) {
        res.status(403).json({ error: "You do not have access to this organization" });
        return;
      }

      await setDefaultOrganization(user.id, orgId);

      res.json({
        message: "Default organization updated",
        defaultOrgId: orgId,
      });
    } catch (error) {
      logger.error("Error setting default organization", { error });
      res.status(500).json({ error: "Failed to set default organization" });
    }
  }
);

/**
 * POST /api/settings/budget-override
 * Set a temporary budget override to bypass budget limits
 */
router.post("/budget-override", async (req: Request, res: Response): Promise<void> => {
  try {
    const org = req.organization!;
    const user = req.user!;
    const { durationMinutes, reason } = req.body;

    // Validate duration (max 24 hours)
    const duration = parseInt(durationMinutes, 10);
    if (isNaN(duration) || duration < 1 || duration > 1440) {
      res.status(400).json({ error: "durationMinutes must be between 1 and 1440 (24 hours)" });
      return;
    }

    // Validate reason
    if (!reason || typeof reason !== "string" || reason.trim().length < 5) {
      res.status(400).json({ error: "reason is required and must be at least 5 characters" });
      return;
    }

    const orgRepo = AppDataSource.getRepository(Organization);

    // Set override
    const overrideUntil = new Date(Date.now() + duration * 60 * 1000);
    org.budgetOverrideUntil = overrideUntil;
    org.budgetOverrideReason = reason.trim();

    await orgRepo.save(org);

    logger.info("Budget override set", {
      orgId: org.id,
      userId: user.id,
      durationMinutes: duration,
      overrideUntil,
      reason: org.budgetOverrideReason,
    });

    res.json({
      success: true,
      budgetOverrideUntil: overrideUntil,
      budgetOverrideReason: org.budgetOverrideReason,
      durationMinutes: duration,
    });
  } catch (error) {
    logger.error("Error setting budget override", { error });
    res.status(500).json({ error: "Failed to set budget override" });
  }
});

/**
 * DELETE /api/settings/budget-override
 * Clear an active budget override
 */
router.delete("/budget-override", async (req: Request, res: Response): Promise<void> => {
  try {
    const org = req.organization!;
    const user = req.user!;

    const orgRepo = AppDataSource.getRepository(Organization);

    // Clear override
    org.budgetOverrideUntil = null;
    org.budgetOverrideReason = null;

    await orgRepo.save(org);

    logger.info("Budget override cleared", {
      orgId: org.id,
      userId: user.id,
    });

    res.json({ success: true });
  } catch (error) {
    logger.error("Error clearing budget override", { error });
    res.status(500).json({ error: "Failed to clear budget override" });
  }
});

/**
 * GET /api/settings/budget-override
 * Get current budget override status
 */
router.get("/budget-override", async (req: Request, res: Response): Promise<void> => {
  try {
    const org = req.organization!;

    const isActive = org.budgetOverrideUntil && new Date() < new Date(org.budgetOverrideUntil);

    res.json({
      isActive,
      budgetOverrideUntil: org.budgetOverrideUntil,
      budgetOverrideReason: org.budgetOverrideReason,
      remainingMinutes: isActive
        ? Math.max(0, Math.ceil((new Date(org.budgetOverrideUntil!).getTime() - Date.now()) / 60000))
        : 0,
    });
  } catch (error) {
    logger.error("Error getting budget override status", { error });
    res.status(500).json({ error: "Failed to get budget override status" });
  }
});

/**
 * GET /api/settings/support/diagnose/:orgName
 * Support admin diagnostic endpoint - shows tenant state
 * Requires supportAdmin flag on user
 */
router.get("/support/diagnose/:orgName", async (req: Request, res: Response): Promise<void> => {
  try {
    const user = req.user!;

    // Only allow support admins - NEVER relax this check
    if (!user.supportAdmin) {
      res.status(403).json({ error: "Support admin access required" });
      return;
    }

    const { orgName } = req.params;
    const orgRepo = AppDataSource.getRepository(Organization);
    const { User, OrgInvite, UserOrganization } = await import("../models/index.js");
    const userRepo = AppDataSource.getRepository(User);
    const inviteRepo = AppDataSource.getRepository(OrgInvite);
    const userOrgRepo = AppDataSource.getRepository(UserOrganization);

    // Find org by name or slug
    const org = await orgRepo
      .createQueryBuilder("org")
      .where("LOWER(org.name) LIKE LOWER(:name)", { name: `%${orgName}%` })
      .orWhere("LOWER(org.slug) = LOWER(:slug)", { slug: orgName })
      .getOne();

    if (!org) {
      res.status(404).json({ error: `Organization not found: ${orgName}` });
      return;
    }

    // Get users via legacy orgId
    const usersViaOrgId = await userRepo.find({
      where: { orgId: org.id },
      select: ["id", "email", "role", "createdAt", "cognitoId"],
    });

    // Get UserOrganization memberships
    const memberships = await userOrgRepo.find({
      where: { orgId: org.id },
      relations: ["user"],
    });

    // Get pending invites
    const invites = await inviteRepo.find({
      where: { orgId: org.id },
    });

    // Check if invited users exist elsewhere
    const inviteAnalysis = [];
    for (const invite of invites) {
      const existingUser = await userRepo.findOne({
        where: { email: invite.email.toLowerCase() },
        select: ["id", "email", "orgId", "cognitoId"],
      });
      inviteAnalysis.push({
        email: invite.email,
        role: invite.role,
        accepted: invite.accepted,
        expired: invite.isExpired(),
        createdAt: invite.createdAt,
        expiresAt: invite.expiresAt,
        userExists: !!existingUser,
        userOrgId: existingUser?.orgId || null,
        userInThisOrg: existingUser?.orgId === org.id,
        hasCognitoId: !!existingUser?.cognitoId,
      });
    }

    // Check secrets in AWS
    const secretsPrefix = `workermill/${config.environment}/orgs/${org.id}/`;
    let secrets: string[] = [];
    try {
      const listResult = await secretsClient.send(
        new ListSecretsCommand({
          Filters: [{ Key: "name", Values: [secretsPrefix] }],
        })
      );
      secrets = (listResult.SecretList || []).map(s => s.Name?.replace(secretsPrefix, "") || "unknown");
    } catch (e) {
      secrets = [`Error listing secrets: ${e}`];
    }

    res.json({
      organization: {
        id: org.id,
        name: org.name,
        slug: org.slug,
        plan: org.plan,
        createdAt: org.createdAt,
      },
      usersViaOrgId: usersViaOrgId.map(u => ({
        id: u.id,
        email: u.email,
        role: u.role,
        hasCognitoId: !!u.cognitoId,
      })),
      userOrganizationRecords: memberships.map(m => ({
        userId: m.userId,
        email: m.user?.email,
        role: m.role,
        isDefault: m.isDefault,
        joinedAt: m.joinedAt,
      })),
      invites: inviteAnalysis,
      secrets,
      issues: [
        ...inviteAnalysis
          .filter(i => !i.accepted && i.userExists && i.userInThisOrg)
          .map(i => `ORPHAN_INVITE: ${i.email} already member but invite exists`),
        ...inviteAnalysis
          .filter(i => !i.accepted && i.userExists && !i.userInThisOrg && i.hasCognitoId)
          .map(i => `USER_WRONG_ORG: ${i.email} exists with different org`),
        ...usersViaOrgId
          .filter(u => !memberships.some(m => m.userId === u.id))
          .map(u => `MISSING_JUNCTION: ${u.email} has orgId but no UserOrganization record`),
      ],
    });
  } catch (error) {
    logger.error("Error in support diagnose", { error });
    res.status(500).json({ error: "Diagnostic failed" });
  }
});

/**
 * GET /api/settings/remote-agents
 * Get connected remote agents for the organization
 */
router.get("/remote-agents", async (req: Request, res: Response) => {
  try {
    const org = req.organization!;
    const { AppDataSource: ds } = await import("../db/connection.js");
    const { RemoteAgent } = await import("../models/RemoteAgent.js");
    const agentRepo = ds.getRepository(RemoteAgent);

    const agents = await agentRepo.find({
      where: { orgId: org.id },
      order: { lastHeartbeatAt: "DESC" },
    });

    const twoMinutesAgo = new Date(Date.now() - 2 * 60 * 1000);

    res.json({
      agents: agents.map((a) => ({
        agentId: a.agentId,
        hostname: a.hostname,
        platform: a.platform,
        nodeVersion: a.nodeVersion,
        dockerVersion: a.dockerVersion,
        claudeVersion: a.claudeVersion,
        maxWorkers: a.maxWorkers,
        activeTasks: a.activeTasks,
        status: a.lastHeartbeatAt > twoMinutesAgo ? "online" : "offline",
        lastHeartbeatAt: a.lastHeartbeatAt,
        createdAt: a.createdAt,
      })),
    });
  } catch (error) {
    logger.error("Error fetching remote agents", { error });
    res.status(500).json({ error: "Failed to fetch remote agents" });
  }
});

export default router;
