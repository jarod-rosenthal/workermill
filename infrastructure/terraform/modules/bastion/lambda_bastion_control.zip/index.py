import boto3
import json
import os
import urllib.request
import ipaddress

def validate_ip(ip_string):
    """Validate that the string is a valid IPv4 or IPv6 address"""
    if not ip_string:
        return False
    try:
        ipaddress.ip_address(ip_string)
        return True
    except ValueError:
        return False

def get_my_ip():
    """Get caller's public IP using ifconfig.me"""
    try:
        req = urllib.request.Request('https://ifconfig.me/ip', headers={'User-Agent': 'curl/7.0'})
        with urllib.request.urlopen(req, timeout=5) as response:
            return response.read().decode('utf-8').strip()
    except Exception as e:
        return None

def update_security_group(ec2, sg_id, allowed_ip):
    """Update security group to allow SSH from the given IP.
    Revokes ALL /32 SSH rules first (cleans up stale entries from any source).
    Static CIDRs from Terraform are wider ranges and won't be affected."""
    cidr = f"{allowed_ip}/32"

    # Get current rules
    sg = ec2.describe_security_groups(GroupIds=[sg_id])['SecurityGroups'][0]

    # Revoke all /32 SSH rules (both Lambda-added and manually-added)
    for rule in sg.get('IpPermissions', []):
        if rule.get('FromPort') == 22 and rule.get('ToPort') == 22:
            stale_cidrs = [r['CidrIp'] for r in rule.get('IpRanges', [])
                          if r['CidrIp'].endswith('/32')]
            if stale_cidrs:
                try:
                    ec2.revoke_security_group_ingress(
                        GroupId=sg_id,
                        IpPermissions=[{
                            'IpProtocol': 'tcp',
                            'FromPort': 22,
                            'ToPort': 22,
                            'IpRanges': [{'CidrIp': c} for c in stale_cidrs]
                        }]
                    )
                except Exception:
                    pass

    # Add new rule
    ec2.authorize_security_group_ingress(
        GroupId=sg_id,
        IpPermissions=[{
            'IpProtocol': 'tcp',
            'FromPort': 22,
            'ToPort': 22,
            'IpRanges': [{'CidrIp': cidr, 'Description': f'Dynamic: Added by Lambda'}]
        }]
    )
    return {'updated': True, 'message': f'Added {cidr} to security group'}

def handler(event, context):
    """
    Start or stop the bastion host by adjusting ASG desired capacity.

    Event payload:
      {"action": "start"}              - Start with auto-detected IP
      {"action": "start", "ip": "x.x.x.x"} - Start with specified IP
      {"action": "stop"}               - Stop the bastion
      {"action": "status"}             - Get current status
      {"action": "whitelist", "ip": "x.x.x.x"} - Just update security group
    """
    asg_name = os.environ['ASG_NAME']
    sg_id = os.environ['SECURITY_GROUP_ID']
    rds_endpoint = os.environ.get('RDS_ENDPOINT', '<rds-endpoint>')

    asg = boto3.client('autoscaling')
    ec2 = boto3.client('ec2')

    action = event.get('action', 'status')

    if action == 'start':
        # Get IP to whitelist
        allowed_ip = event.get('ip')
        if allowed_ip and not validate_ip(allowed_ip):
            return {'status': 'error', 'message': f'Invalid IP address: {allowed_ip}'}
        if not allowed_ip:
            allowed_ip = get_my_ip()

        sg_result = None
        if allowed_ip and validate_ip(allowed_ip):
            try:
                sg_result = update_security_group(ec2, sg_id, allowed_ip)
            except Exception as e:
                sg_result = {'error': str(e)}

        asg.set_desired_capacity(
            AutoScalingGroupName=asg_name,
            DesiredCapacity=1
        )
        return {
            'status': 'starting',
            'message': 'Bastion is starting. Check status in ~60 seconds.',
            'whitelisted_ip': allowed_ip,
            'security_group_update': sg_result
        }

    elif action == 'whitelist':
        allowed_ip = event.get('ip')
        if allowed_ip and not validate_ip(allowed_ip):
            return {'status': 'error', 'message': f'Invalid IP address: {allowed_ip}'}
        if not allowed_ip:
            allowed_ip = get_my_ip()
        if not allowed_ip or not validate_ip(allowed_ip):
            return {'status': 'error', 'message': 'Could not determine valid IP. Pass "ip" parameter.'}

        try:
            sg_result = update_security_group(ec2, sg_id, allowed_ip)
            return {'status': 'success', 'whitelisted_ip': allowed_ip, 'security_group_update': sg_result}
        except Exception as e:
            return {'status': 'error', 'message': str(e)}

    elif action == 'stop':
        asg.set_desired_capacity(
            AutoScalingGroupName=asg_name,
            DesiredCapacity=0
        )
        return {'status': 'stopping', 'message': 'Bastion is stopping.'}

    elif action == 'status':
        # Get ASG info
        response = asg.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
        if not response['AutoScalingGroups']:
            return {'status': 'error', 'message': 'ASG not found'}

        asg_info = response['AutoScalingGroups'][0]
        desired = asg_info['DesiredCapacity']
        instances = asg_info['Instances']

        # Get current whitelisted IPs
        sg = ec2.describe_security_groups(GroupIds=[sg_id])['SecurityGroups'][0]
        whitelisted = []
        for rule in sg.get('IpPermissions', []):
            if rule.get('FromPort') == 22:
                whitelisted = [r['CidrIp'] for r in rule.get('IpRanges', [])]

        if desired == 0:
            return {'status': 'stopped', 'desired_capacity': 0, 'instances': [], 'whitelisted_cidrs': whitelisted}

        if not instances:
            return {'status': 'starting', 'desired_capacity': desired, 'instances': [], 'whitelisted_cidrs': whitelisted}

        # Get instance details
        instance_ids = [i['InstanceId'] for i in instances]
        ec2_response = ec2.describe_instances(InstanceIds=instance_ids)

        instance_info = []
        for reservation in ec2_response['Reservations']:
            for instance in reservation['Instances']:
                instance_info.append({
                    'instance_id': instance['InstanceId'],
                    'state': instance['State']['Name'],
                    'public_ip': instance.get('PublicIpAddress', 'pending'),
                    'instance_type': instance['InstanceType'],
                    'availability_zone': instance['Placement']['AvailabilityZone']
                })

        running = [i for i in instance_info if i['state'] == 'running']
        if running:
            public_ip = running[0]['public_ip']
            return {
                'status': 'running',
                'desired_capacity': desired,
                'instances': instance_info,
                'whitelisted_cidrs': whitelisted,
                'ssh_command': f"ssh -L 5432:{rds_endpoint}:5432 ec2-user@{public_ip}",
                'local_db_url': f"postgresql://workermill:<password>@localhost:5432/workermill"
            }
        else:
            return {
                'status': 'starting',
                'desired_capacity': desired,
                'instances': instance_info,
                'whitelisted_cidrs': whitelisted
            }

    elif action == 'auto_stop_check':
        # Check if bastion is running
        response = asg.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
        if not response['AutoScalingGroups']:
            return {'status': 'no_asg'}

        asg_info = response['AutoScalingGroups'][0]
        if asg_info['DesiredCapacity'] == 0:
            return {'status': 'already_stopped'}

        instances = asg_info['Instances']
        if not instances:
            return {'status': 'no_instances'}

        instance_id = instances[0]['InstanceId']

        # Check instance launch time — skip if less than 25 min old
        # CloudWatch EC2 metrics take ~5 min to populate, and we need
        # 20 min of data for a meaningful idle determination
        import datetime
        ec2_response = ec2.describe_instances(InstanceIds=[instance_id])
        launch_time = ec2_response['Reservations'][0]['Instances'][0]['LaunchTime']
        # launch_time is timezone-aware, so compare with timezone-aware utcnow
        age_minutes = (datetime.datetime.now(datetime.timezone.utc) - launch_time).total_seconds() / 60
        if age_minutes < 25:
            return {
                'status': 'too_young',
                'message': f'Bastion launched {int(age_minutes)} min ago. Skipping idle check (need 25 min).',
                'age_minutes': int(age_minutes)
            }

        # Query CloudWatch for network activity over last 20 minutes
        cw = boto3.client('cloudwatch')
        end_time = datetime.datetime.utcnow()
        start_time = end_time - datetime.timedelta(minutes=20)

        metrics = cw.get_metric_statistics(
            Namespace='AWS/EC2',
            MetricName='NetworkPacketsIn',
            Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
            StartTime=start_time,
            EndTime=end_time,
            Period=300,
            Statistics=['Sum']
        )

        total_packets = sum(dp['Sum'] for dp in metrics.get('Datapoints', []))

        # Threshold: < 50 packets in 20 min means idle (no active SSH tunnel)
        # An active SSH tunnel generates thousands of packets per period
        if total_packets < 50:
            asg.set_desired_capacity(
                AutoScalingGroupName=asg_name,
                DesiredCapacity=0
            )
            return {
                'status': 'stopped_idle',
                'message': f'Bastion idle for 20 min ({int(total_packets)} packets). Stopped.',
                'total_packets': int(total_packets)
            }

        return {
            'status': 'active',
            'message': f'Bastion active ({int(total_packets)} packets in last 20 min).',
            'total_packets': int(total_packets)
        }

    else:
        return {'status': 'error', 'message': f"Unknown action: {action}. Use 'start', 'stop', 'status', or 'whitelist'."}
