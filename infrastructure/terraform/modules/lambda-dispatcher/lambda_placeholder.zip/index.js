exports.handler = async (event) => {
  console.log('Webhook received:', JSON.stringify(event, null, 2));
  return {
    statusCode: 200,
    body: JSON.stringify({ message: 'Placeholder - deploy actual code' })
  };
};
