import json
import boto3
import urllib.request
import urllib.parse
import hmac
import hashlib
import os
import email
from email import policy
from email.parser import BytesParser

def lambda_handler(event, context):
    """
    Process incoming emails from SES via SNS.
    Parses the email and forwards to the WorkerMill API.
    """
    print(f"Received event: {json.dumps(event)}")

    for record in event.get('Records', []):
        # Parse SNS message
        sns_message = json.loads(record['Sns']['Message'])
        message_type = sns_message.get('notificationType')

        if message_type != 'Received':
            print(f"Skipping non-received message type: {message_type}")
            continue

        # Get email content
        mail_data = sns_message.get('mail', {})
        receipt_data = sns_message.get('receipt', {})

        # Extract key information
        message_id = mail_data.get('messageId')
        source = mail_data.get('source')
        recipients = receipt_data.get('recipients', [])
        timestamp = mail_data.get('timestamp')

        # Get S3 location if email is stored there
        s3_info = receipt_data.get('action', {})
        bucket_name = s3_info.get('bucketName')
        object_key = s3_info.get('objectKey')

        # Retrieve full email from S3 if available
        email_content = None
        if bucket_name and object_key:
            s3 = boto3.client('s3')
            try:
                response = s3.get_object(Bucket=bucket_name, Key=object_key)
                raw_email = response['Body'].read()
                msg = BytesParser(policy=policy.default).parsebytes(raw_email)
                email_content = {
                    'subject': str(msg.get('Subject', '')),
                    'body': get_email_body(msg),
                    'html': get_email_html(msg),
                }
            except Exception as e:
                print(f"Error retrieving email from S3: {e}")

        # Build webhook payload
        payload = {
            'messageId': message_id,
            'source': source,
            'recipients': recipients,
            'timestamp': timestamp,
            'content': email_content,
        }

        # Generate HMAC signature
        secret = os.environ.get('WEBHOOK_SECRET', '')
        payload_str = json.dumps(payload, sort_keys=True)
        signature = hmac.new(
            secret.encode('utf-8'),
            payload_str.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()

        # Forward to API
        api_endpoint = os.environ.get('API_ENDPOINT', '')
        if not api_endpoint:
            print("API_ENDPOINT not configured")
            continue

        try:
            req = urllib.request.Request(
                f"{api_endpoint}/api/webhooks/email",
                data=payload_str.encode('utf-8'),
                headers={
                    'Content-Type': 'application/json',
                    'X-Email-Signature': signature,
                },
                method='POST'
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                response_body = response.read().decode('utf-8')
                print(f"API response: {response.status} - {response_body}")

        except Exception as e:
            print(f"Error forwarding to API: {e}")

    return {'statusCode': 200, 'body': 'OK'}


def get_email_body(msg):
    """Extract plain text body from email."""
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == 'text/plain':
                return part.get_payload(decode=True).decode('utf-8', errors='replace')
    else:
        if msg.get_content_type() == 'text/plain':
            return msg.get_payload(decode=True).decode('utf-8', errors='replace')
    return ''


def get_email_html(msg):
    """Extract HTML body from email."""
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == 'text/html':
                return part.get_payload(decode=True).decode('utf-8', errors='replace')
    else:
        if msg.get_content_type() == 'text/html':
            return msg.get_payload(decode=True).decode('utf-8', errors='replace')
    return ''
